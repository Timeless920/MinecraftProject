package com.example.arsenal.combat;

import com.example.arsenal.ArsenalConfig;
import com.example.arsenal.Balance;
import com.example.arsenal.item.ArsenalAxeItem;
import com.example.arsenal.item.ArsenalMeleeItem;
import com.example.arsenal.item.MeleeKind;
import java.util.Map;
import java.util.UUID;
import java.util.WeakHashMap;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.player.AttackEntityEvent;

/** Server-side melee hooks. Register one instance on NeoForge.EVENT_BUS. */
public final class MeleeEvents {
    private record Attack(UUID target, long tick) {}
    private final Map<Player, Attack> attacks = new WeakHashMap<>();
    private boolean cleaving;

    @SubscribeEvent
    public void rememberAttack(AttackEntityEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            attacks.put(player, new Attack(event.getTarget().getUUID(), player.level().getGameTime()));
        }
    }

    private boolean isPrimaryHit(Player player, Entity target) {
        Attack attack = attacks.get(player);
        return attack != null && attack.tick() == player.level().getGameTime()
            && attack.target().equals(target.getUUID());
    }

    private static MeleeKind kind(ItemStack stack) {
        if (stack.getItem() instanceof ArsenalMeleeItem melee) return melee.kind();
        if (stack.getItem() instanceof ArsenalAxeItem) return MeleeKind.BATTLE_AXE;
        return null;
    }

    @SubscribeEvent
    public void incomingDamage(LivingIncomingDamageEvent event) {
        if (cleaving || !(event.getSource().getDirectEntity() instanceof ServerPlayer player)
            || event.getSource().getEntity() != player) return;
        MeleeKind kind = kind(player.getMainHandItem());
        if (kind == null) return;

        float damage = event.getAmount();
        if (ArsenalConfig.WEAPON_FEATURES.get() && isPrimaryHit(player, event.getEntity())) {
            if (kind == MeleeKind.SPEAR && (player.isSprinting() || player.isPassenger())) {
                damage *= Balance.SPEAR_CHARGE_MULTIPLIER;
            } else if (kind == MeleeKind.MACE) {
                damage += (float) Math.min(ArsenalConfig.MAX_MACE_FALL_BONUS.get(),
                    Math.floor(Math.max(0.0F, player.fallDistance)) * Balance.MACE_FALL_DAMAGE_PER_BLOCK);
            }
        }
        event.setAmount((float) (damage * ArsenalConfig.DAMAGE_MULTIPLIER.get()));
    }

    @SubscribeEvent
    public void afterDamage(LivingDamageEvent.Post event) {
        if (cleaving || event.getNewDamage() <= 0 || !ArsenalConfig.WEAPON_FEATURES.get()
            || !(event.getSource().getDirectEntity() instanceof ServerPlayer player)
            || event.getSource().getEntity() != player || !isPrimaryHit(player, event.getEntity())) return;
        LivingEntity victim = event.getEntity();
        MeleeKind kind = kind(player.getMainHandItem());
        if (kind == null) return;
        switch (kind) {
            case KATANA -> {
                if (victim.isAlive() && player.getRandom().nextFloat() < Balance.KATANA_BLEED_CHANCE) {
                    victim.addEffect(new MobEffectInstance(MobEffects.WITHER, Balance.KATANA_BLEED_TICKS, 0), player);
                }
            }
            case BATTLE_AXE -> cleave(player, victim, event.getOriginalDamage());
            case MACE -> {
                if (victim.isAlive()) {
                    victim.knockback(Balance.MACE_KNOCKBACK, player.getX() - victim.getX(), player.getZ() - victim.getZ());
                    victim.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,
                        Balance.MACE_STUN_TICKS, Balance.MACE_STUN_AMPLIFIER), player);
                }
            }
            case SPEAR -> { }
        }
    }

    private void cleave(ServerPlayer player, LivingEntity primary, float originalDamage) {
        cleaving = true;
        try {
            double radius = Balance.AXE_CLEAVE_RADIUS;
            for (LivingEntity candidate : primary.level().getEntitiesOfClass(LivingEntity.class,
                    primary.getBoundingBox().inflate(radius))) {
                if (candidate == player || candidate == primary || !candidate.isAlive()
                    || player.isAlliedTo(candidate) || primary.distanceToSqr(candidate) > radius * radius) continue;
                boolean hostile = candidate instanceof Enemy;
                if (candidate instanceof ServerPlayer other) {
                    hostile = player.server.isPvpAllowed() && player.canHarmPlayer(other);
                }
                if (hostile) {
                    // Vanilla hurt path preserves armor, invulnerability, PvP rules and damage events.
                    candidate.hurt(player.damageSources().playerAttack(player),
                        (float) (originalDamage * Balance.AXE_CLEAVE_DAMAGE * ArsenalConfig.DAMAGE_MULTIPLIER.get()));
                }
            }
        } finally {
            cleaving = false;
        }
    }
}
