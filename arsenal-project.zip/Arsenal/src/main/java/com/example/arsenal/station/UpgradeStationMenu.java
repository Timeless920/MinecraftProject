package com.example.arsenal.station;

import com.example.arsenal.ArsenalConfig;
import com.example.arsenal.ModContent;
import com.example.arsenal.upgrade.UpgradeKind;
import com.example.arsenal.upgrade.Upgrades;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.DataSlot;
import net.minecraft.world.inventory.ResultContainer;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.level.Level;

/** Server-authoritative transaction: merely selecting a recipe never spends inputs. */
public class UpgradeStationMenu extends AbstractContainerMenu {
    public static final int TOOL_SLOT = 0;
    public static final int FIRST_COST_SLOT = 1;
    public static final int SECOND_COST_SLOT = 2;
    public static final int RESULT_SLOT = 3;
    private static final int PLAYER_START = 4;
    private static final int PLAYER_END = 40;
    private static final int HOTBAR_START = 31;

    private final Player owner;
    private final Level level;
    private final ContainerLevelAccess access;
    private final DataSlot selected = DataSlot.standalone();
    private boolean completingTransaction;
    private final SimpleContainer input = new SimpleContainer(3) {
        @Override
        public void setChanged() {
            super.setChanged();
            UpgradeStationMenu.this.slotsChanged(this);
        }
    };
    private final ResultContainer result = new ResultContainer();

    /** Network-side constructor; the server opens the position-aware overload. */
    public UpgradeStationMenu(int id, Inventory inventory) {
        this(id, inventory, ContainerLevelAccess.NULL);
    }

    public UpgradeStationMenu(int id, Inventory inventory, ContainerLevelAccess access) {
        super(ModContent.UPGRADE_MENU.get(), id);
        this.owner = inventory.player;
        this.level = owner.level();
        this.access = access;
        this.selected.set(-1);
        addDataSlot(selected);
        addSlot(new Slot(input, TOOL_SLOT, 8, 20) {
            @Override
            public boolean mayPlace(ItemStack stack) {
                return Arrays.stream(UpgradeKind.values()).anyMatch(kind -> Upgrades.supports(stack, kind));
            }

            @Override
            public int getMaxStackSize() {
                return 1;
            }
        });
        addSlot(new Slot(input, FIRST_COST_SLOT, 8, 44));
        addSlot(new Slot(input, SECOND_COST_SLOT, 30, 44));
        addSlot(new Slot(result, 0, 145, 44) {
            @Override
            public boolean mayPlace(ItemStack stack) {
                return false;
            }

            @Override
            public boolean mayPickup(Player player) {
                return canTakeResult(player);
            }

            @Override
            public void onTake(Player player, ItemStack stack) {
                completeTransaction(player);
                super.onTake(player, stack);
            }
        });
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                addSlot(new Slot(inventory, col + row * 9 + 9, 8 + col * 18, 140 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            addSlot(new Slot(inventory, col, 8 + col * 18, 198));
        }
    }

    /** Stable recipe IDs give identical button indices on client and server. */
    public List<RecipeHolder<UpgradeRecipe>> availableRecipes() {
        return level.getRecipeManager().getAllRecipesFor(ModContent.UPGRADE_RECIPE_TYPE.get()).stream()
                .filter(holder -> holder.value().acceptsTool(input.getItem(TOOL_SLOT)))
                .sorted(Comparator.comparing(holder -> holder.id().toString())).toList();
    }

    public int selectedIndex() {
        return selected.get();
    }

    public UpgradeInput recipeInput() {
        return new UpgradeInput(input.getItem(TOOL_SLOT), input.getItem(FIRST_COST_SLOT),
                input.getItem(SECOND_COST_SLOT));
    }

    public boolean canAfford(UpgradeRecipe recipe, Player player) {
        return recipe.matches(recipeInput(), level)
                && (player.getAbilities().instabuild || player.experienceLevel >= ArsenalConfig.XP_COST.get());
    }

    private UpgradeRecipe selectedRecipe() {
        List<RecipeHolder<UpgradeRecipe>> recipes = availableRecipes();
        int index = selected.get();
        return index >= 0 && index < recipes.size() ? recipes.get(index).value() : null;
    }

    private boolean canTakeResult(Player player) {
        UpgradeRecipe recipe = selectedRecipe();
        if (completingTransaction || recipe == null || !canAfford(recipe, player)) {
            return false;
        }
        // A datapack reload or an in-place component edit can make a previously synced
        // preview stale before the next broadcast. Never trade current inputs for that old item.
        ItemStack preview = result.getItem(0);
        ItemStack expected = recipe.assemble(recipeInput(), level.registryAccess());
        return preview.getCount() == 1 && !expected.isEmpty()
                && ItemStack.isSameItemSameComponents(preview, expected);
    }

    private void refreshOutput() {
        if (level.isClientSide() || completingTransaction) {
            return;
        }
        List<RecipeHolder<UpgradeRecipe>> recipes = availableRecipes();
        if (recipes.isEmpty()) {
            selected.set(-1);
            result.setItem(0, ItemStack.EMPTY);
            return;
        }
        if (selected.get() < 0 || selected.get() >= recipes.size()) {
            selected.set(0);
        }
        UpgradeRecipe recipe = recipes.get(selected.get()).value();
        result.setItem(0, canAfford(recipe, owner)
                ? recipe.assemble(recipeInput(), level.registryAccess()) : ItemStack.EMPTY);
    }

    private void completeTransaction(Player player) {
        if (level.isClientSide()) {
            return;
        }
        UpgradeRecipe recipe = selectedRecipe();
        // Slot.mayPickup and quickMoveStack validate this immediately before the take.
        if (recipe == null || !canAfford(recipe, player) || completingTransaction) {
            return;
        }
        completingTransaction = true;
        try {
            result.setItem(0, ItemStack.EMPTY);
            input.removeItem(TOOL_SLOT, 1);
            input.removeItem(FIRST_COST_SLOT, recipe.cost1().count());
            recipe.cost2().ifPresent(cost -> input.removeItem(SECOND_COST_SLOT, cost.count()));
            if (!player.getAbilities().instabuild) {
                player.giveExperienceLevels(-ArsenalConfig.XP_COST.get());
            }
        } finally {
            completingTransaction = false;
        }
        refreshOutput();
        broadcastChanges();
    }

    @Override
    public boolean clickMenuButton(Player player, int buttonId) {
        if (buttonId < 0 || buttonId >= availableRecipes().size()) {
            return false;
        }
        // Only the server changes the selection. Optimistically changing this DataSlot
        // on the client can stick forever when a stale button index is rejected remotely.
        if (level.isClientSide()) {
            return true;
        }
        selected.set(buttonId);
        refreshOutput();
        broadcastChanges();
        return true;
    }

    @Override
    public void slotsChanged(Container container) {
        super.slotsChanged(container);
        refreshOutput();
    }

    @Override
    public void broadcastChanges() {
        refreshOutput(); // XP can change while the menu is open.
        super.broadcastChanges();
    }

    @Override
    public boolean stillValid(Player player) {
        return stillValid(access, player, ModContent.UPGRADE_STATION.get());
    }

    @Override
    public void removed(Player player) {
        super.removed(player);
        result.clearContent(); // Preview is never a second real item.
        access.execute((world, pos) -> clearContainer(player, input));
    }

    @Override
    public boolean canTakeItemForPickAll(ItemStack stack, Slot slot) {
        return slot.container != result && super.canTakeItemForPickAll(stack, slot);
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        if (index < 0 || index >= slots.size()) {
            return ItemStack.EMPTY;
        }
        Slot slot = slots.get(index);
        if (!slot.hasItem() || !slot.mayPickup(player)) {
            return ItemStack.EMPTY;
        }
        ItemStack moving = slot.getItem();
        ItemStack original = moving.copy();
        if (index == RESULT_SLOT) {
            // All supported tools are single-item stacks: this either moves the whole result or fails.
            if (!moveItemStackTo(moving, PLAYER_START, PLAYER_END, true)) {
                return ItemStack.EMPTY;
            }
            slot.onTake(player, original);
            return original;
        }
        if (index < RESULT_SLOT) {
            if (!moveItemStackTo(moving, PLAYER_START, PLAYER_END, false)) {
                return ItemStack.EMPTY;
            }
        } else if (slots.get(TOOL_SLOT).mayPlace(moving)) {
            if (!moveItemStackTo(moving, TOOL_SLOT, TOOL_SLOT + 1, false)) {
                return ItemStack.EMPTY;
            }
        } else if (!moveItemStackTo(moving, FIRST_COST_SLOT, SECOND_COST_SLOT + 1, false)) {
            if (index < HOTBAR_START) {
                if (!moveItemStackTo(moving, HOTBAR_START, PLAYER_END, false)) {
                    return ItemStack.EMPTY;
                }
            } else if (!moveItemStackTo(moving, PLAYER_START, HOTBAR_START, false)) {
                return ItemStack.EMPTY;
            }
        }
        if (moving.isEmpty()) {
            slot.setByPlayer(ItemStack.EMPTY);
        } else {
            slot.setChanged();
        }
        if (moving.getCount() == original.getCount()) {
            return ItemStack.EMPTY;
        }
        slot.onTake(player, moving);
        return original;
    }
}
