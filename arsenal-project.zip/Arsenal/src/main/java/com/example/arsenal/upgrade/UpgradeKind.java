package com.example.arsenal.upgrade;

import net.minecraft.resources.ResourceLocation;
import com.example.arsenal.Arsenal;

public enum UpgradeKind {
    MINING_SPEED("mining_speed",5), MINING_REACH("mining_reach",5), MINING_RADIUS("mining_radius",2),
    DURABILITY("durability",5), DAMAGE("damage",5), ATTACK_SPEED("attack_speed",3),
    RANGED_DAMAGE("ranged_damage",5), RANGED_SPEED("ranged_speed",5);
    private final String path;
    private final int maxLevel;
    UpgradeKind(String path,int maxLevel) {this.path=path;this.maxLevel=maxLevel;}
    public ResourceLocation id() {return ResourceLocation.fromNamespaceAndPath(Arsenal.MOD_ID,path);}
    public int maxLevel() {return maxLevel;}
    public String translationKey() {return "upgrade.arsenal."+path;}
    public static UpgradeKind byId(ResourceLocation id) {
        for(var kind:values()) if(kind.id().equals(id)) return kind;
        throw new IllegalArgumentException("Unknown Arsenal upgrade: "+id);
    }
}
