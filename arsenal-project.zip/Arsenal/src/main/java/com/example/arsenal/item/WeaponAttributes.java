package com.example.arsenal.item;

import com.example.arsenal.Balance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.component.ItemAttributeModifiers;

public final class WeaponAttributes {
    // Vanilla player base attributes, subtracted to express final requested weapon stats.
    public static final double PLAYER_BASE_ATTACK_DAMAGE = 1.0;
    public static final double PLAYER_BASE_ATTACK_SPEED = 4.0;
    private static final ResourceLocation SPEAR_REACH = ResourceLocation.fromNamespaceAndPath("arsenal", "spear_reach");

    private WeaponAttributes() {}

    public static ItemAttributeModifiers create(Tier tier, MeleeKind kind) {
        var builder = ItemAttributeModifiers.builder()
            .add(Attributes.ATTACK_DAMAGE,
                new AttributeModifier(Item.BASE_ATTACK_DAMAGE_ID,
                    kind.baseDamage() - PLAYER_BASE_ATTACK_DAMAGE + tier.getAttackDamageBonus(),
                    AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.MAINHAND)
            .add(Attributes.ATTACK_SPEED,
                new AttributeModifier(Item.BASE_ATTACK_SPEED_ID,
                    kind.attackSpeed() - PLAYER_BASE_ATTACK_SPEED,
                    AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.MAINHAND);
        if (kind == MeleeKind.SPEAR) {
            builder.add(Attributes.ENTITY_INTERACTION_RANGE,
                new AttributeModifier(SPEAR_REACH, Balance.SPEAR_REACH_BONUS,
                    AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.MAINHAND);
        }
        return builder.build();
    }
}
