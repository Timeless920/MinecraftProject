package com.example.arsenal.station;

import com.example.arsenal.ModContent;
import com.example.arsenal.upgrade.UpgradeKind;
import com.example.arsenal.upgrade.Upgrades;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;

/** Datapack-controlled price of exactly one next upgrade level. */
public record UpgradeRecipe(ResourceLocation upgrade, int level, Cost cost1, Optional<Cost> cost2)
        implements Recipe<UpgradeInput> {
    public static final MapCodec<UpgradeRecipe> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            ResourceLocation.CODEC.fieldOf("upgrade").forGetter(UpgradeRecipe::upgrade),
            Codec.intRange(1, 5).fieldOf("level").forGetter(UpgradeRecipe::level),
            Cost.CODEC.fieldOf("cost1").forGetter(UpgradeRecipe::cost1),
            Cost.CODEC.optionalFieldOf("cost2").forGetter(UpgradeRecipe::cost2)
    ).apply(instance, UpgradeRecipe::new));

    public UpgradeRecipe {
        UpgradeKind kind = UpgradeKind.byId(upgrade);
        if (kind == null || level < 1 || level > kind.maxLevel()) {
            throw new IllegalArgumentException("Unknown upgrade or invalid level: " + upgrade + " " + level);
        }
    }

    public UpgradeKind kind() {
        return UpgradeKind.byId(upgrade);
    }

    public boolean acceptsTool(ItemStack stack) {
        return !stack.isEmpty() && stack.getCount() == 1 && Upgrades.supports(stack, kind())
                && Upgrades.level(stack, kind()) + 1 == level;
    }

    @Override
    public boolean matches(UpgradeInput input, Level world) {
        return acceptsTool(input.tool()) && cost1.matches(input.first())
                && cost2.map(cost -> cost.matches(input.second())).orElse(true);
    }

    @Override
    public ItemStack assemble(UpgradeInput input, HolderLookup.Provider registries) {
        return acceptsTool(input.tool()) ? Upgrades.apply(input.tool(), kind(), level) : ItemStack.EMPTY;
    }

    @Override
    public boolean canCraftInDimensions(int width, int height) {
        return false; // This recipe belongs only to the station, never to a crafting grid.
    }

    @Override
    public ItemStack getResultItem(HolderLookup.Provider registries) {
        return ItemStack.EMPTY; // The result retains the input's item, components, damage and enchantments.
    }

    @Override
    public NonNullList<Ingredient> getIngredients() {
        NonNullList<Ingredient> result = NonNullList.create();
        result.add(cost1.ingredient());
        cost2.ifPresent(cost -> result.add(cost.ingredient()));
        return result;
    }

    @Override
    public boolean isSpecial() {
        return true;
    }

    @Override
    public RecipeSerializer<?> getSerializer() {
        return ModContent.UPGRADE_RECIPE_SERIALIZER.get();
    }

    @Override
    public RecipeType<?> getType() {
        return ModContent.UPGRADE_RECIPE_TYPE.get();
    }

    public record Cost(Ingredient ingredient, int count) {
        public static final Codec<Cost> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                Ingredient.CODEC_NONEMPTY.fieldOf("ingredient").forGetter(Cost::ingredient),
                Codec.intRange(1, 64).fieldOf("count").forGetter(Cost::count)
        ).apply(instance, Cost::new));

        public boolean matches(ItemStack stack) {
            return ingredient.test(stack) && stack.getCount() >= count;
        }
    }

    public static final class Serializer implements RecipeSerializer<UpgradeRecipe> {
        private static final StreamCodec<RegistryFriendlyByteBuf, UpgradeRecipe> STREAM_CODEC =
                ByteBufCodecs.fromCodecWithRegistries(CODEC.codec());

        @Override
        public MapCodec<UpgradeRecipe> codec() {
            return CODEC;
        }

        @Override
        public StreamCodec<RegistryFriendlyByteBuf, UpgradeRecipe> streamCodec() {
            return STREAM_CODEC;
        }
    }
}
