package com.example.arsenal.test;

import com.example.arsenal.Arsenal;
import com.example.arsenal.ArsenalConfig;
import com.example.arsenal.ModContent;
import com.example.arsenal.ModItems;
import com.example.arsenal.station.UpgradeInput;
import com.example.arsenal.station.UpgradeRecipe;
import com.example.arsenal.station.UpgradeStationMenu;
import com.example.arsenal.upgrade.UpgradeKind;
import com.example.arsenal.upgrade.Upgrades;
import io.netty.buffer.Unpooled;
import java.util.HashSet;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.level.GameType;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;
import net.neoforged.neoforge.network.connection.ConnectionType;

/** Integration checks run inside an actual, fully loaded Minecraft server. */
@GameTestHolder(Arsenal.MOD_ID)
@PrefixGameTestTemplate(false)
public final class ArsenalGameTests {
    private ArsenalGameTests() {}

    @GameTest(template = "empty")
    public static void registeredItemSet(GameTestHelper helper) {
        helper.assertValueEqual(ModItems.ITEMS.size(), 34, "weapon item count");
        long registered = BuiltInRegistries.ITEM.keySet().stream()
                .filter(id -> id.getNamespace().equals(Arsenal.MOD_ID)).count();
        helper.assertValueEqual(registered, 35L, "registered weapons plus station item");
        ModItems.ITEMS.forEach((name, item) -> helper.assertTrue(
                BuiltInRegistries.ITEM.get(ResourceLocation.fromNamespaceAndPath(Arsenal.MOD_ID, name)) == item.get(),
                "Missing or incorrectly registered item " + name));
        helper.assertTrue(ModContent.STATION_ITEM.get().getBlock() == ModContent.UPGRADE_STATION.get(),
                "Station item must place the registered station");
        helper.succeed();
    }

    @GameTest(template = "empty")
    public static void stackComponentPersistenceAndNetwork(GameTestHelper helper) {
        ItemStack original = new ItemStack(Items.DIAMOND_SWORD);
        original.setDamageValue(42);
        original.set(DataComponents.CUSTOM_NAME, Component.literal("Arsenal roundtrip test"));
        ItemStack upgraded = Upgrades.apply(Upgrades.apply(original, UpgradeKind.DAMAGE, 1), UpgradeKind.DURABILITY, 1);
        helper.assertFalse(upgraded.isEmpty(), "Vanilla sword must accept compatible upgrades");
        ItemStack disk = ItemStack.parse(helper.getLevel().registryAccess(),
                upgraded.save(helper.getLevel().registryAccess())).orElseThrow();
        helper.assertTrue(ItemStack.isSameItemSameComponents(upgraded, disk),
                "Persistent ItemStack codec lost upgrades, attributes, name, or durability");
        RegistryFriendlyByteBuf buffer = new RegistryFriendlyByteBuf(Unpooled.buffer(),
                helper.getLevel().registryAccess(), ConnectionType.NEOFORGE);
        try {
            ItemStack.STREAM_CODEC.encode(buffer, upgraded);
            ItemStack network = ItemStack.STREAM_CODEC.decode(buffer);
            helper.assertTrue(ItemStack.isSameItemSameComponents(upgraded, network),
                    "Network ItemStack codec lost an upgrade component");
            helper.assertValueEqual(buffer.readableBytes(), 0, "unconsumed network payload");
        } finally {
            buffer.release();
        }
        helper.assertValueEqual(Upgrades.level(original, UpgradeKind.DAMAGE), 0, "original input upgrade level");
        helper.assertValueEqual(original.getDamageValue(), 42, "original damage");
        helper.succeed();
    }

    @GameTest(template = "empty")
    public static void upgradesPreserveAttributeModifiers(GameTestHelper helper) {
        ItemStack spear = new ItemStack(ModItems.ITEMS.get("iron_spear").get());
        ItemAttributeModifiers base = spear.get(DataComponents.ATTRIBUTE_MODIFIERS);
        helper.assertTrue(base != null && base.modifiers().stream()
                .anyMatch(entry -> entry.attribute().equals(Attributes.ENTITY_INTERACTION_RANGE)),
                "Spear must have its base interaction range modifier");
        ResourceLocation externalId = ResourceLocation.fromNamespaceAndPath("arsenal_test", "external_modifier");
        ItemAttributeModifiers withExternal = base.withModifierAdded(Attributes.LUCK,
                new AttributeModifier(externalId, 2, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.MAINHAND);
        spear.set(DataComponents.ATTRIBUTE_MODIFIERS, withExternal);
        ItemStack upgraded = Upgrades.apply(Upgrades.apply(spear, UpgradeKind.DAMAGE, 1), UpgradeKind.DAMAGE, 2);
        upgraded = Upgrades.apply(upgraded, UpgradeKind.ATTACK_SPEED, 1);
        ItemAttributeModifiers result = upgraded.get(DataComponents.ATTRIBUTE_MODIFIERS);
        for (var entry : withExternal.modifiers()) {
            helper.assertTrue(result.modifiers().contains(entry), "Upgrade erased base/external modifier " + entry.modifier().id());
        }
        long damageEntries = result.modifiers().stream().filter(entry -> entry.modifier().id().equals(
                ResourceLocation.fromNamespaceAndPath(Arsenal.MOD_ID, "upgrade/damage"))).count();
        helper.assertValueEqual(damageEntries, 1L, "damage modifiers after sequential upgrades");
        ItemStack vanilla = new ItemStack(Items.IRON_SWORD);
        ItemAttributeModifiers vanillaBase = vanilla.get(DataComponents.ATTRIBUTE_MODIFIERS);
        ItemStack vanillaUpgrade = Upgrades.apply(vanilla, UpgradeKind.ATTACK_SPEED, 1);
        for (var entry : vanillaBase.modifiers()) {
            helper.assertTrue(vanillaUpgrade.get(DataComponents.ATTRIBUTE_MODIFIERS).modifiers().contains(entry),
                    "Upgrade erased vanilla sword modifier " + entry.modifier().id());
        }
        helper.succeed();
    }

    @GameTest(template = "empty")
    public static void upgradeRestrictionsAndSequence(GameTestHelper helper) {
        ItemStack pickaxe = new ItemStack(Items.DIAMOND_PICKAXE);
        helper.assertTrue(Upgrades.supports(pickaxe, UpgradeKind.MINING_RADIUS), "Vanilla pickaxe must support area mining");
        helper.assertFalse(Upgrades.supports(new ItemStack(Items.DIAMOND_SWORD), UpgradeKind.MINING_RADIUS),
                "Sword must not support area mining");
        helper.assertFalse(Upgrades.supports(new ItemStack(Items.STICK), UpgradeKind.DAMAGE), "Stick must not accept damage upgrades");
        helper.assertFalse(Upgrades.supports(pickaxe, UpgradeKind.RANGED_DAMAGE), "Pickaxe must not accept ranged upgrades");
        helper.assertTrue(Upgrades.supports(new ItemStack(Items.BOW), UpgradeKind.RANGED_DAMAGE), "Vanilla bow must be supported");
        helper.assertTrue(Upgrades.supports(new ItemStack(Items.CROSSBOW), UpgradeKind.RANGED_SPEED), "Vanilla crossbow must be supported");
        helper.assertTrue(Upgrades.apply(pickaxe, UpgradeKind.MINING_RADIUS, 2).isEmpty(), "Cannot skip upgrade level I");
        ItemStack first = Upgrades.apply(pickaxe, UpgradeKind.MINING_RADIUS, 1);
        helper.assertFalse(first.isEmpty(), "First radius upgrade failed");
        helper.assertTrue(Upgrades.apply(first, UpgradeKind.MINING_RADIUS, 1).isEmpty(), "Cannot reinstall the same level");
        ItemStack second = Upgrades.apply(first, UpgradeKind.MINING_RADIUS, 2);
        helper.assertValueEqual(Upgrades.level(second, UpgradeKind.MINING_RADIUS), 2, "radius level II");
        helper.assertTrue(Upgrades.apply(second, UpgradeKind.MINING_RADIUS, 3).isEmpty(), "Radius must stop at level II");
        helper.assertTrue(Upgrades.apply(pickaxe.copyWithCount(2), UpgradeKind.MINING_SPEED, 1).isEmpty(),
                "Stacked tools must not produce upgrades");
        helper.assertValueEqual(Upgrades.level(pickaxe, UpgradeKind.MINING_RADIUS), 0, "input must remain unchanged");
        helper.succeed();
    }

    @GameTest(template = "empty")
    public static void dataDrivenUpgradeRecipes(GameTestHelper helper) {
        var recipes = helper.getLevel().getRecipeManager().getAllRecipesFor(ModContent.UPGRADE_RECIPE_TYPE.get());
        helper.assertValueEqual(recipes.size(), 35, "datapack upgrade recipe count");
        var unique = new HashSet<String>();
        for (var holder : recipes) {
            UpgradeRecipe recipe = holder.value();
            helper.assertTrue(unique.add(recipe.upgrade() + "/" + recipe.level()), "Duplicate upgrade level " + holder.id());
            ItemStack tool = switch (recipe.kind()) {
                case MINING_SPEED, MINING_REACH, MINING_RADIUS, DURABILITY -> new ItemStack(Items.DIAMOND_PICKAXE);
                case DAMAGE, ATTACK_SPEED -> new ItemStack(Items.DIAMOND_SWORD);
                case RANGED_DAMAGE, RANGED_SPEED -> new ItemStack(Items.BOW);
            };
            for (int level = 1; level < recipe.level(); level++) {
                tool = Upgrades.apply(tool, recipe.kind(), level);
            }
            ItemStack cost1 = recipe.cost1().ingredient().getItems()[0].copyWithCount(recipe.cost1().count());
            ItemStack cost2 = recipe.cost2().map(cost -> cost.ingredient().getItems()[0].copyWithCount(cost.count()))
                    .orElse(ItemStack.EMPTY);
            UpgradeInput input = new UpgradeInput(tool, cost1, cost2);
            helper.assertTrue(recipe.matches(input, helper.getLevel()), "Valid payment rejected for " + holder.id());
            helper.assertFalse(recipe.matches(new UpgradeInput(tool, ItemStack.EMPTY, cost2), helper.getLevel()),
                    "Missing first payment accepted for " + holder.id());
            if (recipe.cost2().isPresent()) {
                helper.assertFalse(recipe.matches(new UpgradeInput(tool, cost1, ItemStack.EMPTY), helper.getLevel()),
                        "Missing second payment accepted for " + holder.id());
            }
            ItemStack result = recipe.assemble(input, helper.getLevel().registryAccess());
            helper.assertValueEqual(Upgrades.level(result, recipe.kind()), recipe.level(), "assembled upgrade " + holder.id());
            helper.assertValueEqual(Upgrades.level(tool, recipe.kind()), recipe.level() - 1, "unconsumed recipe input");
        }
        helper.succeed();
    }

    @GameTest(template = "empty")
    public static void stationNormalTakeSpendsExactlyOnce(GameTestHelper helper) {
        int previousCost = ArsenalConfig.XP_COST.get();
        ArsenalConfig.XP_COST.set(3);
        try {
            Player player = helper.makeMockPlayer(GameType.SURVIVAL);
            player.experienceLevel = 10;
            UpgradeStationMenu menu = paidMiningMenu(helper, player);
            helper.assertValueEqual(menu.getSlot(1).getItem().getCount(), 24, "payment before taking preview");
            helper.assertValueEqual(player.experienceLevel, 10, "XP before taking preview");
            helper.assertValueEqual(Upgrades.level(menu.getSlot(3).getItem(), UpgradeKind.MINING_SPEED), 1, "result preview");
            menu.clicked(UpgradeStationMenu.RESULT_SLOT, 0, ClickType.PICKUP, player);
            helper.assertValueEqual(Upgrades.level(menu.getCarried(), UpgradeKind.MINING_SPEED), 1, "taken result upgrade");
            helper.assertValueEqual(menu.getCarried().getDamageValue(), 42, "taken tool damage");
            assertCompletedTransaction(helper, menu, player);
            menu.clicked(UpgradeStationMenu.RESULT_SLOT, 0, ClickType.PICKUP, player);
            helper.assertValueEqual(menu.getCarried().getCount(), 1, "repeat-click output count");
            assertCompletedTransaction(helper, menu, player);
        } finally {
            ArsenalConfig.XP_COST.set(previousCost);
        }
        helper.succeed();
    }

    @GameTest(template = "empty")
    public static void stationShiftClickIsAtomic(GameTestHelper helper) {
        int previousCost = ArsenalConfig.XP_COST.get();
        ArsenalConfig.XP_COST.set(3);
        try {
            Player player = helper.makeMockPlayer(GameType.SURVIVAL);
            player.experienceLevel = 10;
            UpgradeStationMenu menu = paidMiningMenu(helper, player);
            for (int index = 0; index < 36; index++) {
                player.getInventory().setItem(index, new ItemStack(Items.COBBLESTONE, 64));
            }
            helper.assertTrue(menu.quickMoveStack(player, UpgradeStationMenu.RESULT_SLOT).isEmpty(),
                    "Full inventory must reject shift-click");
            helper.assertFalse(menu.getSlot(0).getItem().isEmpty(), "Failed shift-click consumed tool");
            helper.assertValueEqual(menu.getSlot(1).getItem().getCount(), 24, "payment after rejected shift-click");
            helper.assertValueEqual(player.experienceLevel, 10, "XP after rejected shift-click");
            player.getInventory().setItem(0, ItemStack.EMPTY);
            menu.clicked(UpgradeStationMenu.RESULT_SLOT, 0, ClickType.QUICK_MOVE, player);
            helper.assertValueEqual(Upgrades.level(player.getInventory().getItem(0), UpgradeKind.MINING_SPEED), 1,
                    "shift-click result in free inventory slot");
            assertCompletedTransaction(helper, menu, player);
            helper.assertTrue(menu.quickMoveStack(player, UpgradeStationMenu.RESULT_SLOT).isEmpty(), "Repeated shift-click duplicated result");
            assertCompletedTransaction(helper, menu, player);

            Player poorPlayer = helper.makeMockPlayer(GameType.SURVIVAL);
            poorPlayer.experienceLevel = 2;
            UpgradeStationMenu poorMenu = paidMiningMenu(helper, poorPlayer);
            helper.assertTrue(poorMenu.getSlot(3).getItem().isEmpty(), "Insufficient XP must not create a result");
            helper.assertTrue(poorMenu.quickMoveStack(poorPlayer, UpgradeStationMenu.RESULT_SLOT).isEmpty(), "Insufficient XP allowed a take");
            helper.assertValueEqual(poorMenu.getSlot(1).getItem().getCount(), 24, "payment after insufficient XP");
            helper.assertFalse(poorMenu.getSlot(0).getItem().isEmpty(), "Insufficient XP consumed tool");
            helper.assertValueEqual(poorPlayer.experienceLevel, 2, "insufficient XP player level");
        } finally {
            ArsenalConfig.XP_COST.set(previousCost);
        }
        helper.succeed();
    }

    private static UpgradeStationMenu paidMiningMenu(GameTestHelper helper, Player player) {
        UpgradeStationMenu menu = new UpgradeStationMenu(1, player.getInventory());
        ItemStack pickaxe = new ItemStack(Items.DIAMOND_PICKAXE);
        pickaxe.setDamageValue(42);
        menu.getSlot(0).set(pickaxe);
        menu.getSlot(1).set(new ItemStack(Items.REDSTONE, 24));
        var recipes = menu.availableRecipes();
        int selected = -1;
        for (int index = 0; index < recipes.size(); index++) {
            if (recipes.get(index).value().kind() == UpgradeKind.MINING_SPEED && recipes.get(index).value().level() == 1) {
                selected = index;
                break;
            }
        }
        helper.assertTrue(selected >= 0 && menu.clickMenuButton(player, selected), "Mining speed recipe button unavailable");
        return menu;
    }

    private static void assertCompletedTransaction(GameTestHelper helper, UpgradeStationMenu menu, Player player) {
        helper.assertTrue(menu.getSlot(0).getItem().isEmpty(), "Tool input must be consumed once");
        helper.assertValueEqual(menu.getSlot(1).getItem().getCount(), 16, "single eight-redstone payment");
        helper.assertTrue(menu.getSlot(3).getItem().isEmpty(), "Preview must clear after transaction");
        helper.assertValueEqual(player.experienceLevel, 7, "single three-level XP payment");
    }
}
