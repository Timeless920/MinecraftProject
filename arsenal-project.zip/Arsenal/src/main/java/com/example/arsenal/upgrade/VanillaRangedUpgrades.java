package com.example.arsenal.upgrade;

import com.example.arsenal.Balance;
import com.example.arsenal.item.MaterialBowItem;
import com.example.arsenal.item.MaterialCrossbowItem;
import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.living.LivingEntityUseItemEvent;
import net.neoforged.neoforge.event.entity.player.ArrowLooseEvent;

/** Adds draw-speed upgrades to vanilla ranged weapons without replacing their firing logic. */
public final class VanillaRangedUpgrades {
    // Logical-client and logical-server entities are distinct keys. The synchronized weak map
    // keeps an integrated server safe and cannot retain players after a level is unloaded.
    private final Map<LivingEntity, ChargeProgress> crossbowProgress =
            Collections.synchronizedMap(new WeakHashMap<>());

    public static double speedMultiplier(ItemStack stack) {
        return 1.0 + Upgrades.level(stack, UpgradeKind.RANGED_SPEED) * Balance.RANGED_UPGRADE_SPEED;
    }

    @SubscribeEvent
    public void bowReleased(ArrowLooseEvent event) {
        ItemStack stack = event.getBow();
        if (!(stack.getItem() instanceof BowItem) || stack.getItem() instanceof MaterialBowItem
                || event.getCharge() < 0 || Upgrades.level(stack, UpgradeKind.RANGED_SPEED) <= 0) {
            return;
        }
        // BowItem applies the normal draw curve, ammo/enchantment hooks and firing after this event.
        event.setCharge((int) Math.floor(event.getCharge() * speedMultiplier(stack)));
    }

    @SubscribeEvent
    public void start(LivingEntityUseItemEvent.Start event) {
        crossbowProgress.remove(event.getEntity());
    }

    @SubscribeEvent
    public void crossbowTick(LivingEntityUseItemEvent.Tick event) {
        ItemStack stack = event.getItem();
        if (!(stack.getItem() instanceof CrossbowItem) || stack.getItem() instanceof MaterialCrossbowItem
                || Upgrades.level(stack, UpgradeKind.RANGED_SPEED) <= 0
                || event.getDuration() <= Balance.CROSSBOW_USE_PADDING_TICKS) {
            return;
        }
        ChargeProgress progress = crossbowProgress.get(event.getEntity());
        if (progress == null || progress.stack != stack || event.getDuration() > progress.lastRemaining) {
            progress = new ChargeProgress(stack);
            crossbowProgress.put(event.getEntity(), progress);
        }
        progress.ticks++;
        int desiredExtra = (int) Math.floor(progress.ticks * speedMultiplier(stack)) - progress.ticks;
        int extra = Math.max(0, desiredExtra - progress.extraApplied);
        int remaining = Math.max(Balance.CROSSBOW_USE_PADDING_TICKS, event.getDuration() - extra);
        progress.extraApplied += event.getDuration() - remaining;
        progress.lastRemaining = remaining;
        // LivingEntity stores this value, invokes CrossbowItem.onUseTick, then decrements it once.
        // Running the same event on both sides also makes the vanilla pull predicate track charging.
        // Padding keeps the timer positive until the vanilla fully-drawn threshold is reached.
        event.setDuration(remaining);
    }

    @SubscribeEvent
    public void stop(LivingEntityUseItemEvent.Stop event) {
        crossbowProgress.remove(event.getEntity());
    }

    @SubscribeEvent
    public void finish(LivingEntityUseItemEvent.Finish event) {
        crossbowProgress.remove(event.getEntity());
    }

    private static final class ChargeProgress {
        private final ItemStack stack;
        private int ticks;
        private int extraApplied;
        private int lastRemaining = Integer.MAX_VALUE;

        private ChargeProgress(ItemStack stack) {
            this.stack = stack;
        }
    }
}
