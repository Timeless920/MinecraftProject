package com.example.arsenal.data;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Complete, deterministic resource definitions, used by the NeoForge DataProvider.
 * The standalone main offers offline resource regeneration; it does not validate game registries.
 * Vanilla formats/tags checked against the extracted Minecraft 1.21.1 data and model JSON.
 */
public final class ResourceCatalog {
    private static final String[] MATERIALS = {"wooden", "stone", "iron", "golden", "diamond", "netherite"};
    private static final String[] MELEE = {"katana", "battle_axe", "spear", "mace"};
    private static final String[] RANGED = {"bow", "crossbow"};
    private final Map<String, Object> definitions = new LinkedHashMap<>();

    private ResourceCatalog() {}

    public static Map<String, String> files() {
        ResourceCatalog catalog = new ResourceCatalog();
        catalog.models();
        catalog.recipes();
        catalog.upgradeRecipes();
        catalog.tags();
        catalog.languages();
        Map<String, String> result = new LinkedHashMap<>();
        catalog.definitions.forEach((path, json) -> result.put(path, json(json) + "\n"));
        return result;
    }

    public static void main(String[] args) throws IOException {
        Path output = Path.of(args.length == 0 ? "src/generated/resources" : args[0]);
        for (var entry : files().entrySet()) {
            Path path = output.resolve(entry.getKey());
            Files.createDirectories(path.getParent());
            Files.writeString(path, entry.getValue(), StandardCharsets.UTF_8);
        }
        System.out.println("Generated " + files().size() + " Arsenal resource JSON files in " + output);
    }

    private void add(String path, Object value) {
        if (definitions.putIfAbsent(path, value) != null) throw new IllegalStateException("Duplicate resource: " + path);
    }

    private void models() {
        for (String material : MATERIALS) {
            for (String kind : MELEE) {
                String item = material + "_" + kind;
                model(item, obj("parent", "minecraft:item/handheld", "textures", obj("layer0", "arsenal:item/" + item)));
            }
            if (material.equals("wooden")) continue;
            for (String kind : RANGED) {
                String item = material + "_" + kind;
                List<Object> overrides = new ArrayList<>();
                float[] thresholds = kind.equals("bow") ? new float[]{0, .65f, .9f} : new float[]{0, .58f, 1};
                for (int i = 0; i < 3; i++) {
                    String variant = item + "_pulling_" + i;
                    Map<String, Object> predicate = obj("pulling", 1);
                    if (i != 0) predicate.put("pull", thresholds[i]);
                    overrides.add(obj("predicate", predicate, "model", "arsenal:item/" + variant));
                    rangedVariant(variant, kind);
                }
                if (kind.equals("crossbow")) {
                    overrides.add(obj("predicate", obj("charged", 1), "model", "arsenal:item/" + item + "_arrow"));
                    overrides.add(obj("predicate", obj("charged", 1, "firework", 1), "model", "arsenal:item/" + item + "_firework"));
                    rangedVariant(item + "_arrow", kind);
                    rangedVariant(item + "_firework", kind);
                }
                model(item, obj("parent", "minecraft:item/" + kind,
                        "textures", obj("layer0", "arsenal:item/" + item), "overrides", overrides));
            }
        }
        add("assets/arsenal/blockstates/upgrade_station.json", obj("variants", obj("", obj("model", "arsenal:block/upgrade_station"))));
        add("assets/arsenal/models/block/upgrade_station.json", obj("parent", "minecraft:block/cube_bottom_top", "textures",
                obj("top", "arsenal:block/upgrade_station_top", "side", "arsenal:block/upgrade_station_side", "bottom", "arsenal:block/upgrade_station_bottom")));
        model("upgrade_station", obj("parent", "arsenal:block/upgrade_station"));
        add("data/arsenal/loot_table/blocks/upgrade_station.json", obj("type", "minecraft:block", "pools", List.of(obj(
                "rolls", 1, "bonus_rolls", 0, "conditions", List.of(obj("condition", "minecraft:survives_explosion")),
                "entries", List.of(obj("type", "minecraft:item", "name", "arsenal:upgrade_station")))),
                "random_sequence", "arsenal:blocks/upgrade_station"));
    }

    private void rangedVariant(String item, String parent) {
        // Empty overrides prevent charged/pulling states recursively inheriting the base model overrides.
        model(item, obj("parent", "minecraft:item/" + parent,
                "textures", obj("layer0", "arsenal:item/" + item), "overrides", List.of()));
    }

    private void model(String name, Object json) {
        add("assets/arsenal/models/item/" + name + ".json", json);
    }

    private void recipes() {
        for (String material : MATERIALS) {
            Map<String, Object> ingredient = materialIngredient(material);
            for (String kind : MELEE) {
                String result = material + "_" + kind;
                if (material.equals("netherite")) {
                    smithing(result, "diamond_" + kind);
                    continue;
                }
                switch (kind) {
                    case "katana" -> shaped(result, List.of(" XX", " X ", "S  "), obj("X", ingredient, "S", item("stick")));
                    case "battle_axe" -> shaped(result, List.of("XXX", "XSX", " S "), obj("X", ingredient, "S", item("stick")));
                    case "spear" -> shaped(result, List.of("  X", " S ", "S  "), obj("X", ingredient, "S", item("stick")));
                    case "mace" -> shaped(result, List.of("XXX", "XSX", " S "), obj("X", ingredient, "S", item("blaze_rod")));
                    default -> throw new IllegalStateException(kind);
                }
            }
            if (material.equals("wooden")) continue;
            for (String kind : RANGED) {
                String result = material + "_" + kind;
                if (material.equals("netherite")) {
                    smithing(result, "diamond_" + kind);
                } else if (kind.equals("bow")) {
                    shaped(result, List.of(" XS", "XBS", " XS"), obj("X", ingredient, "B", item("bow"), "S", item("string")));
                } else {
                    shaped(result, List.of("XSX", "XBX", " T "), obj("X", ingredient, "B", item("crossbow"), "S", item("string"), "T", item("tripwire_hook")));
                }
            }
        }
        shaped("upgrade_station", List.of("III", "OSO", "OOO"), obj("I", item("iron_block"), "O", item("obsidian"), "S", item("smithing_table")));
    }

    private static Map<String, Object> materialIngredient(String material) {
        return switch (material) {
            case "wooden" -> obj("tag", "minecraft:planks");
            case "stone" -> obj("tag", "minecraft:stone_tool_materials");
            case "iron" -> item("iron_ingot");
            case "golden" -> item("gold_ingot");
            case "diamond" -> item("diamond");
            case "netherite" -> item("netherite_ingot");
            default -> throw new IllegalArgumentException(material);
        };
    }

    private void shaped(String name, List<String> pattern, Map<String, Object> key) {
        recipe(name, obj("type", "minecraft:crafting_shaped", "category", name.equals("upgrade_station") ? "misc" : "equipment",
                "pattern", pattern, "key", key, "result", obj("id", "arsenal:" + name, "count", 1)));
        unlock(name, name.equals("upgrade_station") ? item("smithing_table") : materialIngredient(name.substring(0, name.indexOf('_'))));
    }

    private void smithing(String name, String base) {
        recipe(name, obj("type", "minecraft:smithing_transform", "template", item("netherite_upgrade_smithing_template"),
                "base", obj("item", "arsenal:" + base), "addition", item("netherite_ingot"), "result", obj("id", "arsenal:" + name, "count", 1)));
        unlock(name, item("netherite_ingot"));
    }

    private void unlock(String recipe, Map<String, Object> ingredient) {
        String predicate = ingredient.containsKey("tag") ? "#" + ingredient.get("tag") : ingredient.get("item").toString();
        add("data/arsenal/advancement/recipes/" + recipe + ".json", obj("parent", "minecraft:recipes/root",
                "criteria", obj("has_material", obj("trigger", "minecraft:inventory_changed", "conditions", obj("items", List.of(obj("items", predicate)))),
                        "has_the_recipe", obj("trigger", "minecraft:recipe_unlocked", "conditions", obj("recipe", "arsenal:" + recipe))),
                "requirements", List.of(List.of("has_material", "has_the_recipe")), "rewards", obj("recipes", List.of("arsenal:" + recipe))));
    }

    private void recipe(String name, Object json) {
        add("data/arsenal/recipe/" + name + ".json", json);
    }

    private void upgradeRecipes() {
        for (int level = 1; level <= 5; level++) {
            upgrade("mining_speed", level, level <= 3 ? cost("redstone", 8 * level) : cost("redstone_block", 2 * (level - 3)), null);
            upgrade("mining_reach", level, cost(level <= 3 ? "ender_pearl" : "ender_eye", level <= 3 ? level : level - 3), null);
            upgrade("durability", level, cost(level <= 3 ? "obsidian" : "netherite_scrap", level <= 3 ? 4 * level : level - 3), null);
            upgrade("damage", level, cost("quartz", 8 * level), null);
            upgrade("ranged_damage", level, cost("feather", 4 * level), cost("gold_ingot", level));
            upgrade("ranged_speed", level, cost("string", 4 * level), cost("redstone", 4 * level));
        }
        upgrade("mining_radius", 1, cost("diamond_block", 2), null);
        upgrade("mining_radius", 2, cost("netherite_ingot", 2), null);
        for (int level = 1; level <= 3; level++) upgrade("attack_speed", level, cost("blaze_rod", 2 * level), null);
    }

    private static Map<String, Object> cost(String name, int count) {
        return obj("ingredient", item(name), "count", count);
    }

    private void upgrade(String kind, int level, Object cost1, Object cost2) {
        Map<String, Object> json = obj("type", "arsenal:upgrade", "upgrade", "arsenal:" + kind, "level", level, "cost1", cost1);
        if (cost2 != null) json.put("cost2", cost2);
        recipe("upgrade/" + kind + "_" + level, json);
    }

    private void tags() {
        List<String> melee = new ArrayList<>();
        List<String> swords = new ArrayList<>();
        List<String> axes = new ArrayList<>();
        List<String> bows = new ArrayList<>();
        List<String> crossbows = new ArrayList<>();
        for (String material : MATERIALS) {
            for (String kind : MELEE) {
                String item = "arsenal:" + material + "_" + kind;
                melee.add(item);
                (kind.equals("battle_axe") ? axes : swords).add(item);
            }
            if (!material.equals("wooden")) {
                bows.add("arsenal:" + material + "_bow");
                crossbows.add("arsenal:" + material + "_crossbow");
            }
        }
        tag("minecraft", "swords", swords);
        tag("minecraft", "axes", axes);
        tag("minecraft", "enchantable/sword", swords);
        tag("minecraft", "enchantable/weapon", melee);
        tag("minecraft", "enchantable/sharp_weapon", melee);
        tag("minecraft", "enchantable/fire_aspect", swords);
        tag("minecraft", "enchantable/bow", bows);
        tag("minecraft", "enchantable/crossbow", crossbows);
        List<String> all = new ArrayList<>(melee);
        all.addAll(bows);
        all.addAll(crossbows);
        tag("minecraft", "enchantable/durability", all);
        tag("minecraft", "enchantable/vanishing", all);
        tag("minecraft", "enchantable/mining", axes);
        tag("minecraft", "enchantable/mining_loot", axes);
        tag("arsenal", "weapons", melee);
        List<String> ranged = new ArrayList<>(bows);
        ranged.addAll(crossbows);
        tag("arsenal", "ranged_weapons", ranged);
        tag("arsenal", "radius_tools", List.of("#minecraft:pickaxes", "#minecraft:shovels", "#minecraft:axes", "#minecraft:hoes"));
        add("data/minecraft/tags/block/mineable/pickaxe.json", obj("replace", false, "values", List.of("arsenal:upgrade_station")));
    }

    private void tag(String namespace, String name, List<String> values) {
        add("data/" + namespace + "/tags/item/" + name + ".json", obj("replace", false, "values", values));
    }

    private void languages() {
        Map<String, Object> en = new LinkedHashMap<>();
        Map<String, Object> ru = new LinkedHashMap<>();
        String[] englishMaterials = {"Wooden", "Stone", "Iron", "Golden", "Diamond", "Netherite"};
        String[] russianFeminine = {"Деревянная", "Каменная", "Железная", "Золотая", "Алмазная", "Незеритовая"};
        String[] russianNeutral = {"Деревянное", "Каменное", "Железное", "Золотое", "Алмазное", "Незеритовое"};
        String[] russianMasculine = {"Деревянный", "Каменный", "Железный", "Золотой", "Алмазный", "Незеритовый"};
        Map<String, String> englishKinds = Map.of("katana", "Katana", "battle_axe", "Battle Axe", "spear", "Spear", "mace", "Mace", "bow", "Bow", "crossbow", "Crossbow");
        Map<String, String> russianKinds = Map.of("katana", "катана", "battle_axe", "секира", "spear", "копьё", "mace", "булава", "bow", "лук", "crossbow", "арбалет");
        for (int i = 0; i < MATERIALS.length; i++) {
            for (String kind : MELEE) {
                String key = "item.arsenal." + MATERIALS[i] + "_" + kind;
                en.put(key, englishMaterials[i] + " " + englishKinds.get(kind));
                ru.put(key, (kind.equals("spear") ? russianNeutral[i] : russianFeminine[i]) + " " + russianKinds.get(kind));
            }
            if (i > 0) for (String kind : RANGED) {
                String key = "item.arsenal." + MATERIALS[i] + "_" + kind;
                en.put(key, englishMaterials[i] + " " + englishKinds.get(kind));
                ru.put(key, russianMasculine[i] + " " + russianKinds.get(kind));
            }
        }
        translate(en, ru, "itemGroup.arsenal", "Arsenal", "Арсенал");
        translate(en, ru, "block.arsenal.upgrade_station", "Upgrade Station", "Станок улучшений");
        translate(en, ru, "container.arsenal.upgrade_station", "Upgrade Station", "Станок улучшений");
        translate(en, ru, "gui.arsenal.no_upgrades", "Insert an item to view upgrades", "Вставьте предмет для улучшения");
        translate(en, ru, "gui.arsenal.level", "%s %s", "%s %s");
        translate(en, ru, "gui.arsenal.cost", "Cost: %s", "Стоимость: %s");
        translate(en, ru, "gui.arsenal.xp_cost", "XP levels: %s", "Уровней опыта: %s");
        translate(en, ru, "tooltip.arsenal.upgrades", "Upgrades", "Улучшения");
        translate(en, ru, "tooltip.arsenal.upgrade", "%s %s", "%s %s");
        translate(en, ru, "upgrade.arsenal.mining_speed", "Mining Speed", "Скорость копания");
        translate(en, ru, "upgrade.arsenal.mining_reach", "Mining Reach", "Дальность копания");
        translate(en, ru, "upgrade.arsenal.mining_radius", "Mining Area", "Радиус копания");
        translate(en, ru, "upgrade.arsenal.durability", "Durability", "Прочность");
        translate(en, ru, "upgrade.arsenal.damage", "Damage", "Урон");
        translate(en, ru, "upgrade.arsenal.attack_speed", "Attack Speed", "Скорость атаки");
        translate(en, ru, "upgrade.arsenal.ranged_damage", "Projectile Damage", "Урон стрел");
        translate(en, ru, "upgrade.arsenal.ranged_speed", "Draw / Charge Speed", "Скорость натяжения / зарядки");
        translate(en, ru, "tooltip.arsenal.radius_disabled", "Sneak to disable area mining", "Присядьте, чтобы отключить копание по площади");
        translate(en, ru, "config.arsenal.title", "Arsenal configuration", "Настройки Арсенала");
        add("assets/arsenal/lang/en_us.json", en);
        add("assets/arsenal/lang/ru_ru.json", ru);
    }

    private static void translate(Map<String, Object> en, Map<String, Object> ru, String key, String english, String russian) {
        en.put(key, english);
        ru.put(key, russian);
    }

    private static Map<String, Object> item(String id) {
        return obj("item", id.contains(":") ? id : "minecraft:" + id);
    }

    private static Map<String, Object> obj(Object... pairs) {
        if (pairs.length % 2 != 0) throw new IllegalArgumentException("Expected key/value pairs");
        Map<String, Object> result = new LinkedHashMap<>();
        for (int i = 0; i < pairs.length; i += 2) result.put((String) pairs[i], pairs[i + 1]);
        return result;
    }

    /** Small standard-library writer keeps the catalog usable with Java 21 even before game artifacts resolve. */
    private static String json(Object value) {
        if (value instanceof Map<?, ?> map) {
            List<String> entries = new ArrayList<>();
            map.forEach((key, entry) -> entries.add(quote(key.toString()) + ":" + json(entry)));
            return "{" + String.join(",", entries) + "}";
        }
        if (value instanceof List<?> list) return "[" + String.join(",", list.stream().map(ResourceCatalog::json).toList()) + "]";
        if (value instanceof String text) return quote(text);
        if (value instanceof Number || value instanceof Boolean) return value.toString();
        if (value == null) return "null";
        throw new IllegalArgumentException("Unsupported JSON value: " + value.getClass());
    }

    private static String quote(String text) {
        StringBuilder quoted = new StringBuilder("\"");
        for (char ch : text.toCharArray()) {
            switch (ch) {
                case '\\' -> quoted.append("\\\\");
                case '"' -> quoted.append("\\\"");
                case '\n' -> quoted.append("\\n");
                case '\r' -> quoted.append("\\r");
                case '\t' -> quoted.append("\\t");
                default -> {
                    if (ch < 0x20) quoted.append(String.format("\\u%04x", (int) ch));
                    else quoted.append(ch);
                }
            }
        }
        return quoted.append('"').toString();
    }
}
