package com.example.arsenal.upgrade;

import com.example.arsenal.Arsenal;
import com.example.arsenal.Balance;
import java.util.ArrayList;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.*;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.player.ItemTooltipEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class Upgrades {
    public static final DeferredRegister<DataComponentType<?>> COMPONENTS = DeferredRegister.create(Registries.DATA_COMPONENT_TYPE,Arsenal.MOD_ID);
    public static final DeferredHolder<DataComponentType<?>,DataComponentType<UpgradeData>> UPGRADES = COMPONENTS.register("upgrades",
        ()->DataComponentType.<UpgradeData>builder().persistent(UpgradeData.CODEC).networkSynchronized(UpgradeData.STREAM_CODEC).build());

    public static int level(ItemStack stack,UpgradeKind kind) {
        return stack.getOrDefault(UPGRADES.get(),UpgradeData.EMPTY).levels().getOrDefault(kind.id(),0);
    }
    public static boolean supports(ItemStack stack,UpgradeKind kind) {
        if(stack.isEmpty()||stack.getCount()!=1) return false;
        boolean ranged=stack.getItem() instanceof BowItem||stack.getItem() instanceof CrossbowItem;
        boolean mining=stack.has(DataComponents.TOOL);
        boolean area=stack.is(ItemTags.PICKAXES)||stack.is(ItemTags.SHOVELS)||stack.is(ItemTags.AXES)||stack.is(ItemTags.HOES)
            ||stack.getItem() instanceof PickaxeItem||stack.getItem() instanceof ShovelItem||stack.getItem() instanceof AxeItem||stack.getItem() instanceof HoeItem;
        boolean weapon=stack.is(ItemTags.SWORDS)||stack.is(ItemTags.AXES)||stack.getItem() instanceof SwordItem||stack.getItem() instanceof AxeItem||stack.is(Items.MACE)||stack.is(Items.TRIDENT);
        return switch(kind) {
            case MINING_SPEED,MINING_REACH -> mining;
            case MINING_RADIUS -> mining&&area;
            case DURABILITY -> stack.isDamageableItem();
            case DAMAGE,ATTACK_SPEED -> weapon;
            case RANGED_DAMAGE,RANGED_SPEED -> ranged;
        };
    }
    /** Return a new stack; callers consume input only when the player takes this result. */
    public static ItemStack apply(ItemStack original,UpgradeKind kind,int next) {
        if(!supports(original,kind)||next!=level(original,kind)+1||next>kind.maxLevel()) return ItemStack.EMPTY;
        ItemStack stack=original.copyWithCount(1);
        int oldDurability=level(stack,UpgradeKind.DURABILITY);
        stack.set(UPGRADES.get(),stack.getOrDefault(UPGRADES.get(),UpgradeData.EMPTY).with(kind,next));
        if(kind==UpgradeKind.DURABILITY) {
            // Work in raw component units. A ranged item's getMaxDamage may additionally
            // scale the component by its live material-config durability.
            int rawMaximum=original.getOrDefault(DataComponents.MAX_DAMAGE,original.getMaxDamage());
            int base=(int)Math.round(rawMaximum/(1+oldDurability*Balance.DURABILITY_PER_LEVEL));
            stack.set(DataComponents.MAX_DAMAGE,Math.max(1,(int)Math.round(base*(1+next*Balance.DURABILITY_PER_LEVEL))));
        }
        // Preserve vanilla, enchanted and third-party stack modifiers; replace only our upgrade IDs.
        ItemAttributeModifiers previous=stack.getOrDefault(DataComponents.ATTRIBUTE_MODIFIERS,stack.getItem().getDefaultAttributeModifiers(stack));
        var entries=new ArrayList<ItemAttributeModifiers.Entry>();
        for(var entry:previous.modifiers()) {
            var id=entry.modifier().id();
            if(!(id.getNamespace().equals(Arsenal.MOD_ID)&&id.getPath().startsWith("upgrade/")))entries.add(entry);
        }
        var attributes=new ItemAttributeModifiers(entries,previous.showInTooltip());
        int reach=level(stack,UpgradeKind.MINING_REACH), damage=level(stack,UpgradeKind.DAMAGE), speed=level(stack,UpgradeKind.ATTACK_SPEED);
        if(reach>0)attributes=attributes.withModifierAdded(Attributes.BLOCK_INTERACTION_RANGE,modifier("reach",reach*Balance.MINING_REACH_PER_LEVEL,AttributeModifier.Operation.ADD_VALUE),EquipmentSlotGroup.MAINHAND);
        if(damage>0)attributes=attributes.withModifierAdded(Attributes.ATTACK_DAMAGE,modifier("damage",damage*Balance.DAMAGE_PER_LEVEL,AttributeModifier.Operation.ADD_VALUE),EquipmentSlotGroup.MAINHAND);
        if(speed>0)attributes=attributes.withModifierAdded(Attributes.ATTACK_SPEED,modifier("attack_speed",speed*Balance.ATTACK_SPEED_PER_LEVEL,AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL),EquipmentSlotGroup.MAINHAND);
        stack.set(DataComponents.ATTRIBUTE_MODIFIERS,attributes);
        return stack;
    }
    private static AttributeModifier modifier(String path,double amount,AttributeModifier.Operation operation) {
        return new AttributeModifier(ResourceLocation.fromNamespaceAndPath(Arsenal.MOD_ID,"upgrade/"+path),amount,operation);
    }
    @SubscribeEvent public void breakSpeed(PlayerEvent.BreakSpeed event) {
        int level=level(event.getEntity().getMainHandItem(),UpgradeKind.MINING_SPEED);
        if(level>0)event.setNewSpeed((float)(event.getNewSpeed()*(1+level*Balance.MINING_SPEED_PER_LEVEL)));
    }
    @SubscribeEvent public void tooltip(ItemTooltipEvent event) {
        var data=event.getItemStack().getOrDefault(UPGRADES.get(),UpgradeData.EMPTY);
        for(var kind:UpgradeKind.values()) {
            int level=data.levels().getOrDefault(kind.id(),0);
            if(level>0)event.getToolTip().add(Component.translatable(kind.translationKey()).append(" ")
                .append(Component.translatable("enchantment.level."+level)).withStyle(ChatFormatting.AQUA));
        }
    }
}
