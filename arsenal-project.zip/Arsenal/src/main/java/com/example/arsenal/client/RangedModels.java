package com.example.arsenal.client;

import com.example.arsenal.ModItems;
import com.example.arsenal.Balance;
import com.example.arsenal.upgrade.VanillaRangedUpgrades;
import com.example.arsenal.item.MaterialBowItem;
import com.example.arsenal.item.MaterialCrossbowItem;
import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.core.component.DataComponents;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ChargedProjectiles;

/** Referenced exclusively by the physical-client setup subscriber. */
public final class RangedModels {
    private RangedModels() {}

    /** Invoke from FMLClientSetupEvent.enqueueWork. */
    public static void register() {
        // Retain vanilla's predicate and its zero-upgrade result, but show the upgraded draw speed.
        ItemProperties.register(Items.BOW, vanilla("pull"), (stack, level, user, seed) -> {
            if (user == null || user.getUseItem() != stack) return 0.0f;
            float vanillaPull = (float) (stack.getUseDuration(user) - user.getUseItemRemainingTicks())
                    / Balance.VANILLA_BOW_DRAW_TICKS;
            return (float) (vanillaPull * VanillaRangedUpgrades.speedMultiplier(stack));
        });
        ModItems.ITEMS.values().forEach(holder -> {
            var item = holder.get();
            if (item instanceof MaterialBowItem bow) {
                ItemProperties.register(item, vanilla("pull"), (stack, level, user, seed) ->
                        user != null && user.getUseItem() == stack
                                ? (float) (stack.getUseDuration(user) - user.getUseItemRemainingTicks()) / bow.drawTicks(stack) : 0);
                ItemProperties.register(item, vanilla("pulling"), (stack, level, user, seed) ->
                        user != null && user.isUsingItem() && user.getUseItem() == stack ? 1 : 0);
            } else if (item instanceof MaterialCrossbowItem crossbow) {
                ItemProperties.register(item, vanilla("pull"), (stack, level, user, seed) ->
                        user != null && user.getUseItem() == stack && !CrossbowItem.isCharged(stack)
                                ? (float) (stack.getUseDuration(user) - user.getUseItemRemainingTicks()) / crossbow.chargeTicks(stack, user) : 0);
                ItemProperties.register(item, vanilla("pulling"), (stack, level, user, seed) ->
                        user != null && user.isUsingItem() && user.getUseItem() == stack && !CrossbowItem.isCharged(stack) ? 1 : 0);
                ItemProperties.register(item, vanilla("charged"), (stack, level, user, seed) -> CrossbowItem.isCharged(stack) ? 1 : 0);
                ItemProperties.register(item, vanilla("firework"), (stack, level, user, seed) ->
                        stack.getOrDefault(DataComponents.CHARGED_PROJECTILES, ChargedProjectiles.EMPTY).contains(Items.FIREWORK_ROCKET) ? 1 : 0);
            }
        });
    }

    private static ResourceLocation vanilla(String path) {
        return ResourceLocation.fromNamespaceAndPath("minecraft", path);
    }
}
