package com.example.arsenal;

import com.example.arsenal.item.MeleeKind;
import java.util.Collections;
import java.util.EnumMap;
import java.util.Map;
import java.util.LinkedHashMap;
import net.neoforged.neoforge.common.ModConfigSpec;

public final class ArsenalConfig {
    public static final ModConfigSpec SPEC;
    public static final ModConfigSpec.BooleanValue WEAPON_FEATURES, CROUCH_DISABLES_RADIUS;
    public static final ModConfigSpec.DoubleValue DAMAGE_MULTIPLIER, RANGED_DAMAGE_MULTIPLIER, MAX_MACE_FALL_BONUS, HARDNESS_RATIO;
    public static final ModConfigSpec.IntValue MAX_RADIUS, XP_COST;
    public static final Map<MeleeKind, ModConfigSpec.DoubleValue> MELEE_BASE_DAMAGE;
    public static final Map<MeleeKind, ModConfigSpec.DoubleValue> MELEE_ATTACK_SPEED;
    public static final Map<String, ModConfigSpec.IntValue> BOW_DURABILITY, CROSSBOW_DURABILITY;
    public static final Map<String, ModConfigSpec.DoubleValue> BOW_DAMAGE, CROSSBOW_DAMAGE;
    public static final Map<String, ModConfigSpec.IntValue> BOW_DRAW_TICKS, CROSSBOW_DRAW_TICKS;
    static {
        var b = new ModConfigSpec.Builder();
        WEAPON_FEATURES=b.comment("Enable special melee effects").define("weaponFeatures",true);
        DAMAGE_MULTIPLIER=b.defineInRange("meleeDamageMultiplier",1d,0d,100d);
        RANGED_DAMAGE_MULTIPLIER=b.defineInRange("rangedDamageMultiplier",1d,0d,100d);
        MAX_MACE_FALL_BONUS=b.defineInRange("maximumMaceFallBonus",12d,0d,100d);
        MAX_RADIUS=b.comment("Half width: 0 disables area mining, 1 = 3x3, 2 = 5x5").defineInRange("maximumMiningRadius",2,0,2);
        CROUCH_DISABLES_RADIUS=b.define("crouchingDisablesRadius",true);
        HARDNESS_RATIO=b.comment("Skip neighbors harder than original hardness times this value").defineInRange("areaMiningHardnessRatio",1.5d,1d,10d);
        XP_COST=b.comment("XP levels charged per installed upgrade; zero is free").defineInRange("upgradeExperienceLevels",0,0,100);
        var damage = new EnumMap<MeleeKind, ModConfigSpec.DoubleValue>(MeleeKind.class);
        var speed = new EnumMap<MeleeKind, ModConfigSpec.DoubleValue>(MeleeKind.class);
        b.comment("Base damage before the vanilla tier bonus; attack speed is final attacks per second.",
            "Changes affect existing Arsenal melee stacks and preserve installed upgrade modifiers.")
            .push("melee");
        for (var kind : MeleeKind.values()) {
            b.push(kind.id());
            damage.put(kind, b.defineInRange("baseDamage", (double) kind.baseDamage(), 0.0, 100.0));
            speed.put(kind, b.defineInRange("attackSpeed", (double) kind.attackSpeed(), 0.1, 20.0));
            b.pop();
        }
        b.pop();
        MELEE_BASE_DAMAGE = Collections.unmodifiableMap(damage);
        MELEE_ATTACK_SPEED = Collections.unmodifiableMap(speed);
        var bowDurability = new LinkedHashMap<String, ModConfigSpec.IntValue>();
        var crossbowDurability = new LinkedHashMap<String, ModConfigSpec.IntValue>();
        var bowDamage = new LinkedHashMap<String, ModConfigSpec.DoubleValue>();
        var crossbowDamage = new LinkedHashMap<String, ModConfigSpec.DoubleValue>();
        var bowDraw = new LinkedHashMap<String, ModConfigSpec.IntValue>();
        var crossbowDraw = new LinkedHashMap<String, ModConfigSpec.IntValue>();
        b.comment("Per-material values affect existing stacks; installed durability and speed upgrades remain multiplicative.")
                .push("ranged");
        defineRanged(b, "bows", Balance.BOWS, bowDurability, bowDamage, bowDraw);
        defineRanged(b, "crossbows", Balance.CROSSBOWS, crossbowDurability, crossbowDamage, crossbowDraw);
        b.pop();
        BOW_DURABILITY = Collections.unmodifiableMap(bowDurability);
        CROSSBOW_DURABILITY = Collections.unmodifiableMap(crossbowDurability);
        BOW_DAMAGE = Collections.unmodifiableMap(bowDamage);
        CROSSBOW_DAMAGE = Collections.unmodifiableMap(crossbowDamage);
        BOW_DRAW_TICKS = Collections.unmodifiableMap(bowDraw);
        CROSSBOW_DRAW_TICKS = Collections.unmodifiableMap(crossbowDraw);
        SPEC=b.build();
    }
    private static void defineRanged(ModConfigSpec.Builder builder, String section,
            Map<String, Balance.RangedStats> defaults,
            Map<String, ModConfigSpec.IntValue> durability,
            Map<String, ModConfigSpec.DoubleValue> damage,
            Map<String, ModConfigSpec.IntValue> drawTicks) {
        builder.push(section);
        for (String material : new String[]{"stone", "iron", "golden", "diamond", "netherite"}) {
            Balance.RangedStats stats = defaults.get(material);
            builder.push(material);
            durability.put(material, builder.defineInRange("durability", stats.durability(), 1, 1_000_000));
            damage.put(material, builder.defineInRange("damageMultiplier", stats.damageMultiplier(), 0.0, 100.0));
            drawTicks.put(material, builder.comment("Base ticks before Quick Charge or Arsenal speed upgrades.")
                    .defineInRange("drawTicks", stats.drawTicks(), Balance.MIN_DRAW_TICKS, 1200));
            builder.pop();
        }
        builder.pop();
    }

    private static <T> T rangedValue(Map<String, T> values, Balance.RangedStats stats, boolean bow) {
        for (var entry : (bow ? Balance.BOWS : Balance.CROSSBOWS).entrySet()) {
            if (entry.getValue().equals(stats)) return values.get(entry.getKey());
        }
        return null;
    }

    /** Use baseline values during registry bootstrap/datagen, before a server config has been loaded. */
    public static int effectiveDurability(Balance.RangedStats stats, boolean bow) {
        var value = rangedValue(bow ? BOW_DURABILITY : CROSSBOW_DURABILITY, stats, bow);
        return SPEC != null && SPEC.isLoaded() && value != null ? value.get() : stats.durability();
    }

    public static double effectiveMultiplier(Balance.RangedStats stats, boolean bow) {
        var value = rangedValue(bow ? BOW_DAMAGE : CROSSBOW_DAMAGE, stats, bow);
        return SPEC != null && SPEC.isLoaded() && value != null ? value.get() : stats.damageMultiplier();
    }

    public static int effectiveDrawTicks(Balance.RangedStats stats, boolean bow) {
        var value = rangedValue(bow ? BOW_DRAW_TICKS : CROSSBOW_DRAW_TICKS, stats, bow);
        return SPEC != null && SPEC.isLoaded() && value != null ? value.get() : stats.drawTicks();
    }

    private ArsenalConfig() {}
}
