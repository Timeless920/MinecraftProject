package com.example.arsenal.client;

import com.example.arsenal.Arsenal;
import com.example.arsenal.ModContent;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;

@EventBusSubscriber(modid=Arsenal.MOD_ID,bus=EventBusSubscriber.Bus.MOD,value=Dist.CLIENT)
public final class ArsenalClient {
    @SubscribeEvent public static void setup(FMLClientSetupEvent event) {event.enqueueWork(RangedModels::register);}
    @SubscribeEvent public static void screens(RegisterMenuScreensEvent event) {event.register(ModContent.UPGRADE_MENU.get(),UpgradeStationScreen::new);}
    private ArsenalClient() {}
}
