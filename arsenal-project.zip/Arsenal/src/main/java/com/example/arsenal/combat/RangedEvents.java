package com.example.arsenal.combat;

import com.example.arsenal.Arsenal;
import com.example.arsenal.ArsenalConfig;
import com.example.arsenal.Balance;
import com.example.arsenal.item.MaterialBowItem;
import com.example.arsenal.item.MaterialCrossbowItem;
import com.example.arsenal.upgrade.UpgradeKind;
import com.example.arsenal.upgrade.Upgrades;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.FireworkRocketEntity;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ChargedProjectiles;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.NeoForgeRegistries;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

/** Applies ranged multipliers once, after vanilla velocity, critical and Power damage are calculated. */
public final class RangedEvents {
    // A server-side attachment retains the firing stack through chunk unload/reload, unlike a held-item lookup.
    public static final DeferredRegister<AttachmentType<?>> ATTACHMENTS = DeferredRegister.create(NeoForgeRegistries.ATTACHMENT_TYPES, Arsenal.MOD_ID);
    public static final DeferredHolder<AttachmentType<?>, AttachmentType<ItemStack>> PROJECTILE_WEAPON = ATTACHMENTS.register(
            "projectile_weapon", () -> AttachmentType.builder(() -> ItemStack.EMPTY)
                    .serialize(ItemStack.OPTIONAL_CODEC, stack -> !stack.isEmpty()).build());
    private static final Map<LivingEntity, PendingShot> PENDING_SHOTS = new WeakHashMap<>();
    private record PendingShot(long gameTime, ItemStack weapon) {}

    public static void recordFirework(FireworkRocketEntity rocket, ItemStack weapon) {
        if (!rocket.level().isClientSide) {
            rocket.setData(PROJECTILE_WEAPON, weapon.copy());
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void beforeCrossbowShot(PlayerInteractEvent.RightClickItem event) {
        if (event.getLevel().isClientSide) return;
        ItemStack weapon = event.getItemStack();
        if (weapon.getItem() instanceof CrossbowItem && CrossbowItem.isCharged(weapon)
                && weapon.getOrDefault(DataComponents.CHARGED_PROJECTILES, ChargedProjectiles.EMPTY).contains(Items.FIREWORK_ROCKET)) {
            PENDING_SHOTS.put(event.getEntity(), new PendingShot(event.getLevel().getGameTime(), weapon.copy()));
        }
    }

    @SubscribeEvent
    public void onProjectileSpawn(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide || event.loadedFromDisk()
                || !(event.getEntity() instanceof FireworkRocketEntity rocket)
                || rocket.hasData(PROJECTILE_WEAPON)
                || !(rocket.getOwner() instanceof LivingEntity owner)) return;
        PendingShot pending = PENDING_SHOTS.get(owner);
        if (pending != null && pending.gameTime() == event.getLevel().getGameTime()) {
            recordFirework(rocket, pending.weapon());
        }
    }

    @SubscribeEvent(priority = EventPriority.LOW)
    public void onProjectileDamage(LivingIncomingDamageEvent event) {
        if (event.getEntity().level().isClientSide || event.getAmount() <= 0) return;
        ItemStack weapon;
        if (event.getSource().getDirectEntity() instanceof AbstractArrow arrow) {
            weapon = arrow.getWeaponItem(); // Vanilla persists this snapshot even after swapping the held item.
        } else if (event.getSource().getDirectEntity() instanceof FireworkRocketEntity rocket) {
            weapon = rocket.getExistingData(PROJECTILE_WEAPON).orElse(ItemStack.EMPTY);
        } else return;
        if (weapon == null || weapon.isEmpty()) return;

        double multiplier = 1.0;
        if (weapon.getItem() instanceof MaterialBowItem bow) {
            multiplier = ArsenalConfig.effectiveMultiplier(bow.stats(), true) * ArsenalConfig.RANGED_DAMAGE_MULTIPLIER.get();
        } else if (weapon.getItem() instanceof MaterialCrossbowItem crossbow) {
            multiplier = ArsenalConfig.effectiveMultiplier(crossbow.stats(), false) * ArsenalConfig.RANGED_DAMAGE_MULTIPLIER.get();
        }
        multiplier *= 1.0 + Upgrades.level(weapon, UpgradeKind.RANGED_DAMAGE) * Balance.RANGED_UPGRADE_DAMAGE;
        if (Double.isFinite(multiplier) && multiplier >= 0.0 && multiplier != 1.0) {
            event.setAmount((float) Math.min(Float.MAX_VALUE, event.getAmount() * multiplier));
        }
    }
}
