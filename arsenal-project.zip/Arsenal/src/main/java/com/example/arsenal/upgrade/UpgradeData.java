package com.example.arsenal.upgrade;

import com.mojang.serialization.Codec;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.resources.ResourceLocation;

/** Immutable, persistent and synchronized stack data. Never mutate a component in-place. */
public record UpgradeData(Map<ResourceLocation,Integer> levels) {
    public static final UpgradeData EMPTY = new UpgradeData(Map.of());
    public static final Codec<UpgradeData> CODEC = Codec.unboundedMap(ResourceLocation.CODEC,Codec.intRange(1,5)).xmap(UpgradeData::new,UpgradeData::levels);
    public static final StreamCodec<RegistryFriendlyByteBuf,UpgradeData> STREAM_CODEC = StreamCodec.of(
        (buf,value)->{buf.writeVarInt(value.levels.size());value.levels.forEach((id,level)->{buf.writeResourceLocation(id);buf.writeVarInt(level);});},
        buf->{int size=buf.readVarInt();if(size<0||size>UpgradeKind.values().length)throw new IllegalArgumentException("Invalid upgrade count");
            Map<ResourceLocation,Integer> result=new LinkedHashMap<>();
            for(int i=0;i<size;i++)result.put(buf.readResourceLocation(),buf.readVarInt());return new UpgradeData(result);});
    public UpgradeData {
        levels=Map.copyOf(levels);
        levels.forEach((id,level)->{if(level<1||level>UpgradeKind.byId(id).maxLevel())throw new IllegalArgumentException("Invalid upgrade level");});
    }
    public UpgradeData with(UpgradeKind kind,int level) {
        Map<ResourceLocation,Integer> copy=new LinkedHashMap<>(levels);copy.put(kind.id(),level);return new UpgradeData(copy);
    }
}
