package com.example.arsenal.item;

import com.example.arsenal.Balance;
import com.example.arsenal.ArsenalConfig;
import net.minecraft.core.component.DataComponents;
import com.example.arsenal.combat.RangedEvents;
import com.example.arsenal.upgrade.UpgradeKind;
import com.example.arsenal.upgrade.Upgrades;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.FireworkRocketEntity;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Tier;
import net.minecraft.world.level.Level;

/** Rescales vanilla crossbow timing, retaining its projectile and enchantment logic. */
public final class MaterialCrossbowItem extends CrossbowItem {
    private final Tier tier;
    private final Balance.RangedStats stats;

    public MaterialCrossbowItem(Tier tier, Balance.RangedStats stats, Properties properties) {
        super(properties);
        this.tier = tier;
        this.stats = stats;
    }

    public Tier tier() { return tier; }
    public Balance.RangedStats stats() { return stats; }

    public int chargeTicks(ItemStack stack, LivingEntity user) {
        double speed = 1.0 + Upgrades.level(stack, UpgradeKind.RANGED_SPEED) * Balance.RANGED_UPGRADE_SPEED;
        // getChargeDuration applies the real 1.21.1 enchantment charging-time effect (Quick Charge).
        double ticks = (double) getChargeDuration(stack, user) * ArsenalConfig.effectiveDrawTicks(stats, false)
                / Balance.VANILLA_CROSSBOW_DRAW_TICKS / speed;
        return Math.max(Balance.MIN_DRAW_TICKS, (int) Math.ceil(ticks));
    }

    @Override
    public int getUseDuration(ItemStack stack, LivingEntity user) {
        return chargeTicks(stack, user) + Balance.CROSSBOW_USE_PADDING_TICKS;
    }

    private int vanillaRemaining(ItemStack stack, LivingEntity user, int remainingTicks) {
        int elapsed = Math.max(0, getUseDuration(stack, user) - remainingTicks);
        int vanillaElapsed = (int) Math.floor((double) elapsed * Math.max(1, getChargeDuration(stack, user)) / chargeTicks(stack, user));
        return getUseDuration(stack, user) - vanillaElapsed;
    }

    @Override
    public void onUseTick(Level level, LivingEntity user, ItemStack stack, int remainingTicks) {
        super.onUseTick(level, user, stack, vanillaRemaining(stack, user, remainingTicks));
    }

    @Override
    public void releaseUsing(ItemStack stack, Level level, LivingEntity user, int remainingTicks) {
        // Vanilla owns charging, ammo storage, Multishot/Piercing and firework handling.
        super.releaseUsing(stack, level, user, vanillaRemaining(stack, user, remainingTicks));
    }

    @Override
    protected Projectile createProjectile(Level level, LivingEntity user, ItemStack weapon, ItemStack ammunition, boolean critical) {
        Projectile projectile = super.createProjectile(level, user, weapon, ammunition, critical);
        if (projectile instanceof FireworkRocketEntity rocket) {
            RangedEvents.recordFirework(rocket, weapon);
        }
        return projectile;
    }

    @Override
    public int getMaxDamage(ItemStack stack) {
        int raw = stack.getOrDefault(DataComponents.MAX_DAMAGE, stats.durability());
        // The raw component contains upgrades; scale its baseline once, without querying stack.getMaxDamage recursively.
        return Math.max(1, (int) Math.min(Integer.MAX_VALUE, Math.round((double) raw * ArsenalConfig.effectiveDurability(stats, false) / stats.durability())));
    }

    @Override
    public int getEnchantmentValue() {
        return tier.getEnchantmentValue();
    }

    @Override
    public boolean isValidRepairItem(ItemStack stack, ItemStack ingredient) {
        return tier.getRepairIngredient().test(ingredient) || super.isValidRepairItem(stack, ingredient);
    }
}
