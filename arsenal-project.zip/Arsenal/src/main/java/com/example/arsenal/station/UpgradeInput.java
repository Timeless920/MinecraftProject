package com.example.arsenal.station;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeInput;

/** A single tool and two ordered payment slots. */
public record UpgradeInput(ItemStack tool, ItemStack first, ItemStack second) implements RecipeInput {
    @Override
    public ItemStack getItem(int slot) {
        return switch (slot) {
            case 0 -> tool;
            case 1 -> first;
            case 2 -> second;
            default -> throw new IndexOutOfBoundsException(slot);
        };
    }

    @Override
    public int size() {
        return 3;
    }
}
