package com.example.arsenal.upgrade;

import com.example.arsenal.ArsenalConfig;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.level.BlockEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/** Server-only area mining. Every extra block goes through the ordinary player break pipeline. */
public final class AreaMining {
    private final Map<UUID, ClickedFace> clickedFaces = new HashMap<>();
    private final List<PendingBreak> pending = new ArrayList<>();
    private final Set<UUID> mining = new HashSet<>();

    @SubscribeEvent
    public void rememberFace(PlayerInteractEvent.LeftClickBlock event) {
        if (event.getEntity() instanceof ServerPlayer player && event.getFace() != null) {
            clickedFaces.put(player.getUUID(), new ClickedFace(event.getPos().immutable(), event.getFace()));
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void plan(BlockEvent.BreakEvent event) {
        if (!(event.getPlayer() instanceof ServerPlayer player) || mining.contains(player.getUUID())
                || player.gameMode.getGameModeForPlayer() != GameType.SURVIVAL) {
            return;
        }
        ItemStack tool = player.getMainHandItem();
        int radius = Math.min(Upgrades.level(tool, UpgradeKind.MINING_RADIUS), ArsenalConfig.MAX_RADIUS.get());
        if (radius <= 0 || !Upgrades.supports(tool, UpgradeKind.MINING_RADIUS)
                || ArsenalConfig.CROUCH_DISABLES_RADIUS.get() && player.isShiftKeyDown()) {
            return;
        }
        ClickedFace click = clickedFaces.get(player.getUUID());
        BlockState state = event.getState();
        float hardness = state.getDestroySpeed(player.level(), event.getPos());
        if (click == null || !click.pos().equals(event.getPos()) || hardness < 0
                || tool.getDestroySpeed(state) <= 1.0F || !tool.isCorrectToolForDrops(state)) {
            return;
        }
        // A later listener can still cancel this event. Keep the event and recheck its final
        // cancellation state AND actual block removal at the end of this server tick.
        pending.add(new PendingBreak(player, player.serverLevel(), event, tool, click.face(), radius, hardness));
    }

    @SubscribeEvent
    public void afterTick(ServerTickEvent.Post event) {
        List<PendingBreak> ready = new ArrayList<>();
        pending.removeIf(plan -> {
            if (plan.level().getServer() == event.getServer()) {
                ready.add(plan);
                return true;
            }
            return false;
        });
        for (PendingBreak plan : ready) {
            mine(plan);
        }
    }

    private void mine(PendingBreak plan) {
        ServerPlayer player = plan.player();
        BlockPos origin = plan.event().getPos();
        if (plan.event().isCanceled() || player.isRemoved() || player.serverLevel() != plan.level()
                || player.getMainHandItem() != plan.tool() || plan.tool().isEmpty()
                || plan.level().getBlockState(origin).equals(plan.event().getState())
                || ArsenalConfig.CROUCH_DISABLES_RADIUS.get() && player.isShiftKeyDown()) {
            return;
        }
        Direction.Axis normal = plan.face().getAxis();
        mining.add(player.getUUID());
        try {
            for (int first = -plan.radius(); first <= plan.radius(); first++) {
                for (int second = -plan.radius(); second <= plan.radius(); second++) {
                    if (first == 0 && second == 0) {
                        continue;
                    }
                    if (plan.tool().isEmpty() || player.getMainHandItem() != plan.tool()) {
                        return; // Stop immediately when the tool breaks; never switch to bare hands.
                    }
                    BlockPos target = switch (normal) {
                        case X -> origin.offset(0, first, second);
                        case Y -> origin.offset(first, 0, second);
                        case Z -> origin.offset(first, second, 0);
                    };
                    if (eligible(plan, target)) {
                        // This patched vanilla method fires BreakEvent, consumes normal durability,
                        // and runs playerDestroy for vanilla loot, Fortune/Silk Touch, and XP.
                        player.gameMode.destroyBlock(target);
                    }
                }
            }
        } finally {
            mining.remove(player.getUUID());
        }
    }

    private boolean eligible(PendingBreak plan, BlockPos pos) {
        ServerLevel level = plan.level();
        if (level.isOutsideBuildHeight(pos) || !level.hasChunkAt(pos)
                || !level.getWorldBorder().isWithinBounds(pos) || !level.mayInteract(plan.player(), pos)) {
            return false;
        }
        BlockState state = level.getBlockState(pos);
        float hardness = state.getDestroySpeed(level, pos);
        return !state.isAir() && hardness >= 0
                && hardness <= plan.hardness() * ArsenalConfig.HARDNESS_RATIO.get()
                && plan.tool().getDestroySpeed(state) > 1.0F
                && plan.tool().isCorrectToolForDrops(state)
                && state.canHarvestBlock(level, pos, plan.player());
    }

    @SubscribeEvent
    public void logout(PlayerEvent.PlayerLoggedOutEvent event) {
        UUID id = event.getEntity().getUUID();
        clickedFaces.remove(id);
        pending.removeIf(plan -> plan.player().getUUID().equals(id));
        mining.remove(id);
    }

    private record ClickedFace(BlockPos pos, Direction face) {}

    private record PendingBreak(ServerPlayer player, ServerLevel level, BlockEvent.BreakEvent event,
                                ItemStack tool, Direction face, int radius, float hardness) {}
}
