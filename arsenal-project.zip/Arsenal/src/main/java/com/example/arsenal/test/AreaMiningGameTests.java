package com.example.arsenal.test;

import com.example.arsenal.Arsenal;
import com.example.arsenal.upgrade.UpgradeKind;
import com.example.arsenal.upgrade.Upgrades;
import com.mojang.authlib.GameProfile;
import java.util.UUID;
import java.util.function.Consumer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.common.util.FakePlayer;
import net.neoforged.neoforge.event.level.BlockEvent;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/** Tests the ordinary player-break pipeline, not a direct call into the area miner. */
@GameTestHolder(Arsenal.MOD_ID)
@PrefixGameTestTemplate(false)
public final class AreaMiningGameTests {
    private AreaMiningGameTests() {}

    @GameTest(template = "empty", timeoutTicks = 30)
    public static void radiusOneBreaksOnePlaneWithNormalDurability(GameTestHelper helper) {
        runMiningScenario(helper, false);
    }

    @GameTest(template = "empty", timeoutTicks = 30)
    public static void radiusOneHonorsProtectionCancellation(GameTestHelper helper) {
        runMiningScenario(helper, true);
    }

    private static void runMiningScenario(GameTestHelper helper, boolean protectNeighbor) {
        BlockPos relativeCenter = new BlockPos(2, 2, 2);
        BlockPos center = helper.absolutePos(relativeCenter);
        BlockPos protectedPosition = helper.absolutePos(new BlockPos(1, 2, 1));
        // The outer ring must survive. A recursive 3x3 implementation would expand into it.
        for (int x = 0; x < 5; x++) {
            for (int z = 0; z < 5; z++) {
                helper.setBlock(new BlockPos(x, 2, z), Blocks.STONE);
            }
        }
        // The parallel plane verifies that the remembered UP face selects the horizontal plane only.
        helper.setBlock(new BlockPos(2, 1, 2), Blocks.STONE);
        FakePlayer player = new FakePlayer(helper.getLevel(),
                new GameProfile(UUID.randomUUID(), "ArsenalAreaTest"));
        player.setGameMode(GameType.SURVIVAL);
        player.setPos(center.getX() + 0.5, center.getY() + 1, center.getZ() + 0.5);
        player.setOnGround(true);
        ItemStack tool = Upgrades.apply(new ItemStack(Items.DIAMOND_PICKAXE), UpgradeKind.MINING_RADIUS, 1);
        player.setItemInHand(InteractionHand.MAIN_HAND, tool);
        Consumer<BlockEvent.BreakEvent> protection = event -> {
            if (protectNeighbor && event.getPlayer() == player && event.getPos().equals(protectedPosition)) {
                event.setCanceled(true);
            }
        };
        NeoForge.EVENT_BUS.addListener(EventPriority.HIGHEST, BlockEvent.BreakEvent.class, protection);
        try {
            // This is the real start-destroy action and therefore records the clicked face through
            // NeoForge's real LeftClickBlock event before normal survival block destruction.
            player.gameMode.handleBlockBreakAction(center, ServerboundPlayerActionPacket.Action.START_DESTROY_BLOCK,
                    Direction.UP, helper.getLevel().getMaxBuildHeight(), 0);
            helper.assertTrue(player.gameMode.destroyBlock(center), "Primary survival block break failed");
            helper.assertTrue(helper.getLevel().getBlockState(center).isAir(), "Primary block must be removed");
            helper.runAfterDelay(3, () -> {
                try {
                    int expected = protectNeighbor ? 8 : 9;
                    int removed = 0;
                    for (int x = 0; x < 5; x++) {
                        for (int z = 0; z < 5; z++) {
                            BlockPos relative = new BlockPos(x, 2, z);
                            boolean inside = x >= 1 && x <= 3 && z >= 1 && z <= 3;
                            boolean protectedBlock = protectNeighbor && x == 1 && z == 1;
                            if (inside && !protectedBlock) {
                                helper.assertTrue(helper.getBlockState(relative).isAir(), "Expected mined block at " + relative);
                                removed++;
                            } else {
                                helper.assertBlockPresent(Blocks.STONE, relative);
                            }
                        }
                    }
                    helper.assertValueEqual(removed, expected, "removed plane blocks");
                    helper.assertBlockPresent(Blocks.STONE, new BlockPos(2, 1, 2));
                    helper.assertValueEqual(player.getMainHandItem().getDamageValue(), expected,
                            "one normal durability point per successfully mined block");
                    int drops = helper.getLevel().getEntitiesOfClass(ItemEntity.class, helper.getBounds()).stream()
                            .map(ItemEntity::getItem).filter(stack -> stack.is(Items.COBBLESTONE))
                            .mapToInt(ItemStack::getCount).sum();
                    helper.assertValueEqual(drops, expected, "normal stone drops");
                    helper.succeed();
                } finally {
                    NeoForge.EVENT_BUS.unregister(protection);
                }
            });
        } catch (RuntimeException | Error exception) {
            NeoForge.EVENT_BUS.unregister(protection);
            throw exception;
        }
    }
}
