package com.example.arsenal.item;

/** Default melee balance table. Attack speeds are final attacks/second, not attribute offsets. */
public enum MeleeKind {
    KATANA("katana", 3.0F, 2.0F),
    BATTLE_AXE("battle_axe", 7.0F, 0.9F),
    SPEAR("spear", 4.0F, 1.3F),
    MACE("mace", 8.0F, 0.8F);

    private final String id;
    private final float baseDamage;
    private final float attackSpeed;

    MeleeKind(String id, float baseDamage, float attackSpeed) {
        this.id = id;
        this.baseDamage = baseDamage;
        this.attackSpeed = attackSpeed;
    }

    public String id() { return id; }
    public float baseDamage() { return baseDamage; }
    public float attackSpeed() { return attackSpeed; }
}
