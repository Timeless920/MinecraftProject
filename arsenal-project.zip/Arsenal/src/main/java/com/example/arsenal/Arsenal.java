package com.example.arsenal;

import com.example.arsenal.combat.MeleeEvents;
import com.example.arsenal.combat.MeleeStats;
import com.example.arsenal.combat.RangedEvents;
import com.example.arsenal.data.ArsenalData;
import com.example.arsenal.upgrade.*;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.common.NeoForge;

@Mod(Arsenal.MOD_ID)
public final class Arsenal {
    public static final String MOD_ID="arsenal";
    public Arsenal(IEventBus modBus,ModContainer container) {
        ModContent.register(modBus);
        ModItems.REGISTER.register(modBus);
        Upgrades.COMPONENTS.register(modBus);
        RangedEvents.ATTACHMENTS.register(modBus);
        container.registerConfig(ModConfig.Type.SERVER,ArsenalConfig.SPEC);
        modBus.addListener(ArsenalData::gather);
        NeoForge.EVENT_BUS.register(new MeleeEvents());
        NeoForge.EVENT_BUS.register(new MeleeStats());
        NeoForge.EVENT_BUS.register(new RangedEvents());
        NeoForge.EVENT_BUS.register(new Upgrades());
        NeoForge.EVENT_BUS.register(new AreaMining());
        NeoForge.EVENT_BUS.register(new VanillaRangedUpgrades());
    }
}
