package com.example.arsenal.combat;

import com.example.arsenal.ArsenalConfig;
import com.example.arsenal.item.ArsenalAxeItem;
import com.example.arsenal.item.ArsenalMeleeItem;
import com.example.arsenal.item.MeleeKind;
import com.example.arsenal.item.WeaponAttributes;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Tier;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.ItemAttributeModifierEvent;

/** Resolves live server-config values without accessing config during item registration or datagen. */
public final class MeleeStats {
    @SubscribeEvent
    public void attributes(ItemAttributeModifierEvent event) {
        // SERVER config is synchronized to connected clients. Registration/datagen uses table defaults.
        if (!ArsenalConfig.SPEC.isLoaded()) return;
        MeleeKind kind;
        Tier tier;
        var item = event.getItemStack().getItem();
        if (item instanceof ArsenalMeleeItem melee) {
            kind = melee.kind();
            tier = melee.tier();
        } else if (item instanceof ArsenalAxeItem axe) {
            kind = axe.kind();
            tier = axe.tier();
        } else {
            return;
        }
        // Leave upgrade, reach and third-party modifiers intact, including component overrides.
        boolean hasDamage = event.getModifiers().stream().anyMatch(entry ->
            entry.attribute().equals(Attributes.ATTACK_DAMAGE)
                && entry.modifier().id().equals(Item.BASE_ATTACK_DAMAGE_ID)
                && entry.slot() == EquipmentSlotGroup.MAINHAND);
        boolean hasSpeed = event.getModifiers().stream().anyMatch(entry ->
            entry.attribute().equals(Attributes.ATTACK_SPEED)
                && entry.modifier().id().equals(Item.BASE_ATTACK_SPEED_ID)
                && entry.slot() == EquipmentSlotGroup.MAINHAND);
        if (hasDamage) {
            double damage = ArsenalConfig.MELEE_BASE_DAMAGE.get(kind).get()
                - WeaponAttributes.PLAYER_BASE_ATTACK_DAMAGE + tier.getAttackDamageBonus();
            event.replaceModifier(Attributes.ATTACK_DAMAGE,
                new AttributeModifier(Item.BASE_ATTACK_DAMAGE_ID, damage, AttributeModifier.Operation.ADD_VALUE),
                EquipmentSlotGroup.MAINHAND);
        }
        if (hasSpeed) {
            double speed = ArsenalConfig.MELEE_ATTACK_SPEED.get(kind).get()
                - WeaponAttributes.PLAYER_BASE_ATTACK_SPEED;
            event.replaceModifier(Attributes.ATTACK_SPEED,
                new AttributeModifier(Item.BASE_ATTACK_SPEED_ID, speed, AttributeModifier.Operation.ADD_VALUE),
                EquipmentSlotGroup.MAINHAND);
        }
    }
}
