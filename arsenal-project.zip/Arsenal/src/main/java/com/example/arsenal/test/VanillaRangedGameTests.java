package com.example.arsenal.test;

import com.example.arsenal.Arsenal;
import com.example.arsenal.Balance;
import com.example.arsenal.ModItems;
import com.example.arsenal.item.MaterialCrossbowItem;
import com.example.arsenal.upgrade.UpgradeKind;
import com.example.arsenal.upgrade.Upgrades;
import net.minecraft.core.registries.Registries;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.GameType;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.living.LivingEntityUseItemEvent;
import net.neoforged.neoforge.event.entity.player.ArrowLooseEvent;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

@GameTestHolder(Arsenal.MOD_ID)
@PrefixGameTestTemplate(false)
public final class VanillaRangedGameTests {
    private VanillaRangedGameTests() {}

    @GameTest(template = "empty")
    public static void vanillaBowUpgradeAndMaterialExclusion(GameTestHelper helper) {
        Player user = helper.makeMockPlayer(GameType.SURVIVAL);
        ItemStack bow = Upgrades.apply(new ItemStack(Items.BOW), UpgradeKind.RANGED_SPEED, 1);
        int threshold = (int) Math.ceil(Balance.VANILLA_BOW_DRAW_TICKS / (1.0 + Balance.RANGED_UPGRADE_SPEED));
        var before = new ArrowLooseEvent(user, bow, helper.getLevel(), threshold - 1, true);
        NeoForge.EVENT_BUS.post(before);
        helper.assertTrue(before.getCharge() < Balance.VANILLA_BOW_DRAW_TICKS, "Vanilla bow charged too early");
        var full = new ArrowLooseEvent(user, bow, helper.getLevel(), threshold, true);
        NeoForge.EVENT_BUS.post(full);
        helper.assertTrue(full.getCharge() >= Balance.VANILLA_BOW_DRAW_TICKS, "Vanilla bow speed upgrade failed");
        ItemStack materialBow = Upgrades.apply(new ItemStack(ModItems.ITEMS.get("stone_bow").get()), UpgradeKind.RANGED_SPEED, 1);
        var material = new ArrowLooseEvent(user, materialBow, helper.getLevel(), Balance.VANILLA_BOW_DRAW_TICKS, true);
        NeoForge.EVENT_BUS.post(material);
        helper.assertValueEqual(material.getCharge(), Balance.VANILLA_BOW_DRAW_TICKS, "Material bow timing was multiplied twice");
        helper.succeed();
    }

    @GameTest(template = "empty")
    public static void vanillaCrossbowSpeedAndQuickCharge(GameTestHelper helper) {
        Player user = helper.makeMockPlayer(GameType.SURVIVAL);
        ItemStack weapon = Upgrades.apply(new ItemStack(Items.CROSSBOW), UpgradeKind.RANGED_SPEED, 1);
        assertVanillaChargeThreshold(helper, user, weapon);
        ItemStack quick = weapon.copy();
        quick.enchant(helper.getLevel().registryAccess().registryOrThrow(Registries.ENCHANTMENT)
                .getHolderOrThrow(Enchantments.QUICK_CHARGE), 3);
        assertVanillaChargeThreshold(helper, user, quick);

        ItemStack material = Upgrades.apply(new ItemStack(ModItems.ITEMS.get("stone_crossbow").get()), UpgradeKind.RANGED_SPEED, 1);
        int materialRemaining = ((MaterialCrossbowItem) material.getItem()).getUseDuration(material, user);
        var event = new LivingEntityUseItemEvent.Tick(user, material, materialRemaining);
        NeoForge.EVENT_BUS.post(event);
        helper.assertValueEqual(event.getDuration(), materialRemaining, "Material crossbow timer was accelerated twice");
        helper.succeed();
    }

    private static void assertVanillaChargeThreshold(GameTestHelper helper, Player user, ItemStack source) {
        ItemStack weapon = source.copy();
        user.setItemInHand(InteractionHand.MAIN_HAND, weapon);
        user.setItemInHand(InteractionHand.OFF_HAND, new ItemStack(Items.ARROW, 8));
        int duration = weapon.getUseDuration(user);
        int ticks = (int) Math.ceil(CrossbowItem.getChargeDuration(weapon, user) / (1.0 + Balance.RANGED_UPGRADE_SPEED));
        int remaining = duration;
        NeoForge.EVENT_BUS.post(new LivingEntityUseItemEvent.Start(user, weapon, InteractionHand.MAIN_HAND, duration));
        for (int tick = 0; tick < ticks; tick++) {
            if (tick == ticks - 1) {
                ((CrossbowItem) weapon.getItem()).releaseUsing(weapon, helper.getLevel(), user, remaining);
                helper.assertFalse(CrossbowItem.isCharged(weapon), "Vanilla crossbow charged before upgrade threshold");
            }
            var useTick = new LivingEntityUseItemEvent.Tick(user, weapon, remaining);
            NeoForge.EVENT_BUS.post(useTick);
            remaining = useTick.getDuration() - 1; // Exact LivingEntity.updateUsingItem countdown order.
        }
        ((CrossbowItem) weapon.getItem()).releaseUsing(weapon, helper.getLevel(), user, remaining);
        helper.assertTrue(CrossbowItem.isCharged(weapon), "Vanilla crossbow speed/Quick Charge threshold failed");
        helper.assertValueEqual(user.getOffhandItem().getCount(), 7, "Vanilla crossbow consumed incorrect ammunition");
        NeoForge.EVENT_BUS.post(new LivingEntityUseItemEvent.Stop(user, weapon, remaining));
    }
}
