package com.example.arsenal.test;

import com.example.arsenal.Arsenal;
import com.example.arsenal.ArsenalConfig;
import com.example.arsenal.station.UpgradeStationMenu;
import com.example.arsenal.upgrade.UpgradeKind;
import com.example.arsenal.upgrade.Upgrades;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.GameType;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/** Regression coverage for nonstandard inventory actions and stale result previews. */
@GameTestHolder(Arsenal.MOD_ID)
@PrefixGameTestTemplate(false)
public final class StationEdgeGameTests {
    private StationEdgeGameTests() {}

    @GameTest(template = "empty")
    public static void stalePreviewCannotRepairTool(GameTestHelper helper) {
        int previousCost = ArsenalConfig.XP_COST.get();
        ArsenalConfig.XP_COST.set(3);
        try {
            Player player = helper.makeMockPlayer(GameType.SURVIVAL);
            UpgradeStationMenu menu = paidMenu(helper, player);
            helper.assertValueEqual(menu.getSlot(3).getItem().getDamageValue(), 42, "initial preview damage");
            // Deliberately mutate in place, without a container notification or intervening broadcast.
            menu.getSlot(0).getItem().setDamageValue(99);
            helper.assertFalse(menu.getSlot(3).mayPickup(player), "A stale result must not be pickable");
            menu.clicked(UpgradeStationMenu.RESULT_SLOT, 0, ClickType.PICKUP, player);
            helper.assertTrue(menu.getCarried().isEmpty(), "Stale preview escaped to the cursor");
            helper.assertValueEqual(menu.getSlot(0).getItem().getDamageValue(), 99, "unchanged input damage");
            helper.assertValueEqual(menu.getSlot(1).getItem().getCount(), 24, "unspent stale-preview payment");
            helper.assertValueEqual(player.experienceLevel, 10, "unspent stale-preview XP");
            menu.broadcastChanges();
            helper.assertTrue(menu.getSlot(3).mayPickup(player), "Refreshed preview must become pickable");
            menu.clicked(UpgradeStationMenu.RESULT_SLOT, 0, ClickType.PICKUP, player);
            helper.assertValueEqual(menu.getCarried().getDamageValue(), 99, "upgrade must preserve current tool damage");
            helper.assertValueEqual(Upgrades.level(menu.getCarried(), UpgradeKind.MINING_SPEED), 1, "refreshed result upgrade");
            assertSpentOnce(helper, menu, player);
        } finally {
            ArsenalConfig.XP_COST.set(previousCost);
        }
        helper.succeed();
    }

    @GameTest(template = "empty")
    public static void hotbarSwapSpendsExactlyOnce(GameTestHelper helper) {
        int previousCost = ArsenalConfig.XP_COST.get();
        ArsenalConfig.XP_COST.set(3);
        try {
            Player player = helper.makeMockPlayer(GameType.SURVIVAL);
            UpgradeStationMenu menu = paidMenu(helper, player);
            player.getInventory().setItem(0, ItemStack.EMPTY);
            menu.clicked(UpgradeStationMenu.RESULT_SLOT, 0, ClickType.SWAP, player);
            ItemStack received = player.getInventory().getItem(0);
            helper.assertValueEqual(Upgrades.level(received, UpgradeKind.MINING_SPEED), 1, "hotbar result upgrade");
            helper.assertValueEqual(received.getDamageValue(), 42, "hotbar result damage");
            assertSpentOnce(helper, menu, player);
            menu.clicked(UpgradeStationMenu.RESULT_SLOT, 0, ClickType.SWAP, player);
            helper.assertTrue(ItemStack.isSameItemSameComponents(player.getInventory().getItem(0), received),
                    "Repeated swap changed the received tool");
            helper.assertValueEqual(player.getInventory().getItem(0).getCount(), 1, "hotbar result count");
            assertSpentOnce(helper, menu, player);
        } finally {
            ArsenalConfig.XP_COST.set(previousCost);
        }
        helper.succeed();
    }

    @GameTest(template = "empty")
    public static void throwingResultSpendsExactlyOnce(GameTestHelper helper) {
        int previousCost = ArsenalConfig.XP_COST.get();
        ArsenalConfig.XP_COST.set(3);
        try {
            Player player = helper.makeMockPlayer(GameType.SURVIVAL);
            player.setPos(helper.absolutePos(new BlockPos(1, 1, 1)).getCenter());
            UpgradeStationMenu menu = paidMenu(helper, player);
            menu.clicked(UpgradeStationMenu.RESULT_SLOT, 0, ClickType.THROW, player);
            assertSpentOnce(helper, menu, player);
            menu.clicked(UpgradeStationMenu.RESULT_SLOT, 0, ClickType.THROW, player);
            List<ItemEntity> outputs = helper.getLevel().getEntitiesOfClass(ItemEntity.class,
                    player.getBoundingBox().inflate(4), entity -> entity.getItem().getHoverName().getString()
                            .equals(testName(player)));
            helper.assertValueEqual(outputs.size(), 1, "single thrown result entity");
            helper.assertValueEqual(outputs.getFirst().getItem().getCount(), 1, "thrown result count");
            helper.assertValueEqual(Upgrades.level(outputs.getFirst().getItem(), UpgradeKind.MINING_SPEED), 1,
                    "thrown result upgrade");
            assertSpentOnce(helper, menu, player);
        } finally {
            ArsenalConfig.XP_COST.set(previousCost);
        }
        helper.succeed();
    }

    private static UpgradeStationMenu paidMenu(GameTestHelper helper, Player player) {
        player.experienceLevel = 10;
        UpgradeStationMenu menu = new UpgradeStationMenu(1, player.getInventory());
        ItemStack tool = new ItemStack(Items.DIAMOND_PICKAXE);
        tool.setDamageValue(42);
        tool.set(DataComponents.CUSTOM_NAME, Component.literal(testName(player)));
        menu.getSlot(0).set(tool);
        menu.getSlot(1).set(new ItemStack(Items.REDSTONE, 24));
        var recipes = menu.availableRecipes();
        int index = -1;
        for (int i = 0; i < recipes.size(); i++) {
            if (recipes.get(i).value().kind() == UpgradeKind.MINING_SPEED) {
                index = i;
                break;
            }
        }
        helper.assertTrue(index >= 0 && menu.clickMenuButton(player, index), "Mining speed recipe must be selectable");
        return menu;
    }

    private static String testName(Player player) {
        return "station-edge-test-" + player.getUUID();
    }

    private static void assertSpentOnce(GameTestHelper helper, UpgradeStationMenu menu, Player player) {
        helper.assertTrue(menu.getSlot(0).getItem().isEmpty(), "single tool input consumed");
        helper.assertTrue(menu.getSlot(3).getItem().isEmpty(), "result cleared after taking");
        helper.assertValueEqual(menu.getSlot(1).getItem().getCount(), 16, "single eight-redstone payment");
        helper.assertValueEqual(player.experienceLevel, 7, "single three-level XP payment");
    }
}
