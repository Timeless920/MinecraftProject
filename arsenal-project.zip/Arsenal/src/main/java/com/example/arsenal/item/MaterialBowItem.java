package com.example.arsenal.item;

import com.example.arsenal.Balance;
import com.example.arsenal.ArsenalConfig;
import net.minecraft.core.component.DataComponents;
import com.example.arsenal.upgrade.UpgradeKind;
import com.example.arsenal.upgrade.Upgrades;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Tier;
import net.minecraft.world.level.Level;

/** A vanilla bow with tier repair/enchantability and a configurable draw curve. */
public final class MaterialBowItem extends BowItem {
    private final Tier tier;
    private final Balance.RangedStats stats;

    public MaterialBowItem(Tier tier, Balance.RangedStats stats, Properties properties) {
        super(properties);
        this.tier = tier;
        this.stats = stats;
    }

    public Tier tier() { return tier; }
    public Balance.RangedStats stats() { return stats; }

    public int drawTicks(ItemStack stack) {
        double speed = 1.0 + Upgrades.level(stack, UpgradeKind.RANGED_SPEED) * Balance.RANGED_UPGRADE_SPEED;
        return Math.max(Balance.MIN_DRAW_TICKS, (int) Math.ceil(ArsenalConfig.effectiveDrawTicks(stats, true) / speed));
    }

    @Override
    public void releaseUsing(ItemStack stack, Level level, LivingEntity user, int remainingTicks) {
        int elapsed = Math.max(0, getUseDuration(stack, user) - remainingTicks);
        int vanillaElapsed = (int) Math.floor((double) elapsed * Balance.VANILLA_BOW_DRAW_TICKS / drawTicks(stack));
        // Keep vanilla consumption, Infinity, Power, Punch, Flame, tipped/spectral ammo and NeoForge hooks.
        super.releaseUsing(stack, level, user, getUseDuration(stack, user) - vanillaElapsed);
    }

    @Override
    public int getMaxDamage(ItemStack stack) {
        int raw = stack.getOrDefault(DataComponents.MAX_DAMAGE, stats.durability());
        // The raw component contains upgrades; scale its baseline once, without querying stack.getMaxDamage recursively.
        return Math.max(1, (int) Math.min(Integer.MAX_VALUE, Math.round((double) raw * ArsenalConfig.effectiveDurability(stats, true) / stats.durability())));
    }

    @Override
    public int getEnchantmentValue() {
        return tier.getEnchantmentValue();
    }

    @Override
    public boolean isValidRepairItem(ItemStack stack, ItemStack ingredient) {
        return tier.getRepairIngredient().test(ingredient) || super.isValidRepairItem(stack, ingredient);
    }
}
