package com.example.arsenal;

import java.util.Map;

/** One table for balance defaults. Live world options are in ArsenalConfig. */
public final class Balance {
    private Balance() {}
    public static final double KATANA_BLEED_CHANCE = .20;
    public static final int KATANA_BLEED_TICKS = 60;
    public static final double AXE_CLEAVE_RADIUS = 2;
    public static final float AXE_CLEAVE_DAMAGE = .5f;
    public static final float SPEAR_CHARGE_MULTIPLIER = 1.5f;
    public static final double SPEAR_REACH_BONUS = 1.5;
    public static final double MACE_KNOCKBACK = 1.5;
    public static final int MACE_STUN_TICKS = 40, MACE_STUN_AMPLIFIER = 1;
    public static final float MACE_FALL_DAMAGE_PER_BLOCK = 1;
    public static final double MINING_SPEED_PER_LEVEL = .15, MINING_REACH_PER_LEVEL = .5;
    public static final double DURABILITY_PER_LEVEL = .20, DAMAGE_PER_LEVEL = 1, ATTACK_SPEED_PER_LEVEL = .10;
    public static final double RANGED_UPGRADE_DAMAGE = .15, RANGED_UPGRADE_SPEED = .10;
    public static final int MIN_DRAW_TICKS = 4;
    public static final int VANILLA_BOW_DRAW_TICKS = 20, VANILLA_CROSSBOW_DRAW_TICKS = 25, CROSSBOW_USE_PADDING_TICKS = 3;
    public record RangedStats(int durability, double damageMultiplier, int drawTicks) {}
    public static final Map<String, RangedStats> BOWS = Map.of(
        "stone", new RangedStats(450,1.10,20), "iron", new RangedStats(650,1.25,18),
        "golden",new RangedStats(300,1.10,14), "diamond",new RangedStats(1200,1.50,16),
        "netherite",new RangedStats(1500,1.75,14));
    public static final Map<String, RangedStats> CROSSBOWS = Map.of(
        "stone",new RangedStats(500,1.10,25),"iron",new RangedStats(700,1.25,23),
        "golden",new RangedStats(350,1.10,18),"diamond",new RangedStats(1300,1.50,21),
        "netherite",new RangedStats(1600,1.75,19));
}
