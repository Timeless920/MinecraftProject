package com.example.arsenal;

import com.example.arsenal.item.*;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.world.item.*;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModItems {
    public static final DeferredRegister.Items REGISTER=DeferredRegister.createItems(Arsenal.MOD_ID);
    public static final Map<String,DeferredItem<Item>> ITEMS=new LinkedHashMap<>();
    static {
        Map<String,Tier> tiers=new LinkedHashMap<>();
        tiers.put("wooden",Tiers.WOOD);tiers.put("stone",Tiers.STONE);tiers.put("iron",Tiers.IRON);
        tiers.put("golden",Tiers.GOLD);tiers.put("diamond",Tiers.DIAMOND);tiers.put("netherite",Tiers.NETHERITE);
        tiers.forEach((material,tier)->{
            register(material+"_katana",()->new ArsenalMeleeItem(tier,MeleeKind.KATANA,properties(material)));
            register(material+"_battle_axe",()->new ArsenalAxeItem(tier,properties(material)));
            register(material+"_spear",()->new ArsenalMeleeItem(tier,MeleeKind.SPEAR,properties(material)));
            register(material+"_mace",()->new ArsenalMeleeItem(tier,MeleeKind.MACE,properties(material)));
            if(!material.equals("wooden")) {
                var bow=Balance.BOWS.get(material);var crossbow=Balance.CROSSBOWS.get(material);
                register(material+"_bow",()->new MaterialBowItem(tier,bow,properties(material).durability(bow.durability())));
                register(material+"_crossbow",()->new MaterialCrossbowItem(tier,crossbow,properties(material).durability(crossbow.durability())));
            }
        });
    }
    private static Item.Properties properties(String material) {
        var p=new Item.Properties();return material.equals("netherite")?p.fireResistant():p;
    }
    private static void register(String name,java.util.function.Supplier<Item> factory) {ITEMS.put(name,REGISTER.register(name,factory));}
    private ModItems() {}
}
