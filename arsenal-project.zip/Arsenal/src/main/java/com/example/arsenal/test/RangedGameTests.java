package com.example.arsenal.test;

import com.example.arsenal.Arsenal;
import com.example.arsenal.ArsenalConfig;
import com.example.arsenal.ModItems;
import com.example.arsenal.combat.RangedEvents;
import com.example.arsenal.item.MaterialCrossbowItem;
import com.example.arsenal.upgrade.UpgradeKind;
import com.example.arsenal.upgrade.Upgrades;
import net.minecraft.core.registries.Registries;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.entity.projectile.FireworkRocketEntity;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.GameType;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.common.damagesource.DamageContainer;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

@GameTestHolder(Arsenal.MOD_ID)
@PrefixGameTestTemplate(false)
public final class RangedGameTests {
    private RangedGameTests() {}

    @GameTest(template = "empty")
    public static void crossbowChargeThresholdAndQuickCharge(GameTestHelper helper) {
        Player user = helper.makeMockPlayer(GameType.SURVIVAL);
        for (String material : new String[]{"stone", "iron", "golden", "diamond", "netherite"}) {
            ItemStack plain = new ItemStack(ModItems.ITEMS.get(material + "_crossbow").get());
            var item = (MaterialCrossbowItem) plain.getItem();
            assertChargesExactlyAtThreshold(helper, user, plain);
            ItemStack upgraded = Upgrades.apply(plain, UpgradeKind.RANGED_SPEED, 1);
            helper.assertTrue(item.chargeTicks(upgraded, user) < item.chargeTicks(plain, user),
                    material + " crossbow speed upgrade must reduce charge duration");
            assertChargesExactlyAtThreshold(helper, user, upgraded);
            ItemStack enchanted = new ItemStack(item);
            enchanted.enchant(helper.getLevel().registryAccess().registryOrThrow(Registries.ENCHANTMENT)
                    .getHolderOrThrow(Enchantments.QUICK_CHARGE), 3);
            helper.assertTrue(item.chargeTicks(enchanted, user) < item.chargeTicks(plain, user),
                    material + " crossbow must retain Quick Charge");
            assertChargesExactlyAtThreshold(helper, user, enchanted);
        }
        helper.succeed();
    }

    private static void assertChargesExactlyAtThreshold(GameTestHelper helper, Player user, ItemStack source) {
        ItemStack weapon = source.copy();
        MaterialCrossbowItem item = (MaterialCrossbowItem) weapon.getItem();
        user.setItemInHand(InteractionHand.MAIN_HAND, weapon);
        user.setItemInHand(InteractionHand.OFF_HAND, new ItemStack(Items.SPECTRAL_ARROW, 8));
        int duration = item.getUseDuration(weapon, user);
        int charge = item.chargeTicks(weapon, user);
        item.releaseUsing(weapon, helper.getLevel(), user, duration - charge + 1);
        helper.assertFalse(CrossbowItem.isCharged(weapon), "Crossbow charged one tick too early");
        helper.assertValueEqual(user.getOffhandItem().getCount(), 8, "ammo before full charge");
        item.releaseUsing(weapon, helper.getLevel(), user, duration - charge);
        helper.assertTrue(CrossbowItem.isCharged(weapon), "Crossbow failed to charge at its configured threshold");
        helper.assertValueEqual(user.getOffhandItem().getCount(), 7, "ammo after full charge");
    }

    @GameTest(template = "empty")
    public static void arrowUsesFiringSnapshotAndOneMultiplier(GameTestHelper helper) {
        double previous = ArsenalConfig.RANGED_DAMAGE_MULTIPLIER.get();
        ArsenalConfig.RANGED_DAMAGE_MULTIPLIER.set(1.0);
        try {
            Player user = helper.makeMockPlayer(GameType.SURVIVAL);
            ItemStack weapon = Upgrades.apply(new ItemStack(ModItems.ITEMS.get("netherite_bow").get()), UpgradeKind.RANGED_DAMAGE, 1);
            Arrow arrow = new Arrow(helper.getLevel(), user, new ItemStack(Items.ARROW), weapon);
            // Neither replacing the held item nor modifying the original firing stack may change a projectile in flight.
            user.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(Items.STICK));
            weapon.set(Upgrades.UPGRADES.get(), weapon.get(Upgrades.UPGRADES.get()).with(UpgradeKind.RANGED_DAMAGE, 5));
            var event = new LivingIncomingDamageEvent(user,
                    new DamageContainer(helper.getLevel().damageSources().arrow(arrow, user), 10));
            NeoForge.EVENT_BUS.post(event);
            helper.assertTrue(Math.abs(event.getAmount() - 20.125f) < 0.0001f,
                    "Arrow must apply netherite 1.75x and firing-snapshot level I 1.15x exactly once");
        } finally {
            ArsenalConfig.RANGED_DAMAGE_MULTIPLIER.set(previous);
        }
        helper.succeed();
    }

    @GameTest(template = "empty")
    public static void fireworkSourcePersistsThroughEntitySave(GameTestHelper helper) {
        double previous = ArsenalConfig.RANGED_DAMAGE_MULTIPLIER.get();
        ArsenalConfig.RANGED_DAMAGE_MULTIPLIER.set(1.0);
        try {
            Player user = helper.makeMockPlayer(GameType.SURVIVAL);
            ItemStack weapon = Upgrades.apply(new ItemStack(ModItems.ITEMS.get("diamond_crossbow").get()), UpgradeKind.RANGED_DAMAGE, 1);
            FireworkRocketEntity rocket = new FireworkRocketEntity(EntityType.FIREWORK_ROCKET, helper.getLevel());
            RangedEvents.recordFirework(rocket, weapon);
            CompoundTag saved = rocket.saveWithoutId(new CompoundTag());
            FireworkRocketEntity restored = new FireworkRocketEntity(EntityType.FIREWORK_ROCKET, helper.getLevel());
            restored.load(saved);
            helper.assertTrue(ItemStack.isSameItemSameComponents(weapon, restored.getData(RangedEvents.PROJECTILE_WEAPON)),
                    "Rocket entity persistence lost the source ItemStack attachment");
            var event = new LivingIncomingDamageEvent(user,
                    new DamageContainer(helper.getLevel().damageSources().fireworks(restored, user), 10));
            NeoForge.EVENT_BUS.post(event);
            helper.assertTrue(Math.abs(event.getAmount() - 17.25f) < 0.0001f,
                    "Restored firework must retain diamond 1.5x and level I 1.15x multipliers");
        } finally {
            ArsenalConfig.RANGED_DAMAGE_MULTIPLIER.set(previous);
        }
        helper.succeed();
    }
}
