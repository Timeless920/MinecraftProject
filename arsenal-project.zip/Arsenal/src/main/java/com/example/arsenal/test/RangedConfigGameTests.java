package com.example.arsenal.test;

import com.example.arsenal.Arsenal;
import com.example.arsenal.ArsenalConfig;
import com.example.arsenal.ModItems;
import com.example.arsenal.item.MaterialBowItem;
import com.example.arsenal.item.MaterialCrossbowItem;
import com.example.arsenal.upgrade.UpgradeKind;
import com.example.arsenal.upgrade.Upgrades;
import net.minecraft.core.component.DataComponents;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.GameType;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.common.damagesource.DamageContainer;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

@GameTestHolder(Arsenal.MOD_ID)
@PrefixGameTestTemplate(false)
public final class RangedConfigGameTests {
    private RangedConfigGameTests() {}

    @GameTest(template = "empty")
    public static void liveBowConfigAndDurabilityUpgrades(GameTestHelper helper) {
        var durability = ArsenalConfig.BOW_DURABILITY.get("stone");
        var damage = ArsenalConfig.BOW_DAMAGE.get("stone");
        var draw = ArsenalConfig.BOW_DRAW_TICKS.get("stone");
        int oldDurability = durability.get();
        double oldDamage = damage.get();
        int oldDraw = draw.get();
        double oldGlobalDamage = ArsenalConfig.RANGED_DAMAGE_MULTIPLIER.get();
        ItemStack existing = new ItemStack(ModItems.ITEMS.get("stone_bow").get());
        existing.setDamageValue(42);
        try {
            durability.set(900);
            damage.set(2.0);
            draw.set(10);
            ArsenalConfig.RANGED_DAMAGE_MULTIPLIER.set(1.0);
            helper.assertValueEqual(existing.getMaxDamage(), 900, "existing bow live-config durability");
            helper.assertValueEqual(((MaterialBowItem) existing.getItem()).drawTicks(existing), 10, "existing bow live-config draw ticks");
            ItemStack upgraded = Upgrades.apply(existing, UpgradeKind.DURABILITY, 1);
            helper.assertValueEqual(upgraded.getOrDefault(DataComponents.MAX_DAMAGE, 0), 540,
                    "raw bow durability must retain a single baseline-plus-upgrade scale");
            helper.assertValueEqual(upgraded.getMaxDamage(), 1080, "configured bow durability with level I");
            ItemStack second = Upgrades.apply(upgraded, UpgradeKind.DURABILITY, 2);
            helper.assertValueEqual(second.getMaxDamage(), 1260, "configured bow durability with level II must not compound");
            helper.assertValueEqual(second.getDamageValue(), 42, "config and upgrades must preserve tool wear");
            durability.set(450);
            helper.assertValueEqual(second.getMaxDamage(), 630, "existing upgraded bow must follow another config change once");

            Player player = helper.makeMockPlayer(GameType.SURVIVAL);
            Arrow arrow = new Arrow(helper.getLevel(), player, new ItemStack(Items.ARROW), existing);
            var event = new LivingIncomingDamageEvent(player,
                    new DamageContainer(helper.getLevel().damageSources().arrow(arrow, player), 10));
            NeoForge.EVENT_BUS.post(event);
            helper.assertTrue(Math.abs(event.getAmount() - 20f) < 0.0001f,
                    "Existing bow projectiles must apply the configured material damage multiplier");
        } finally {
            durability.set(oldDurability);
            damage.set(oldDamage);
            draw.set(oldDraw);
            ArsenalConfig.RANGED_DAMAGE_MULTIPLIER.set(oldGlobalDamage);
        }
        helper.succeed();
    }

    @GameTest(template = "empty")
    public static void liveCrossbowConfigAndDurabilityUpgrades(GameTestHelper helper) {
        var durability = ArsenalConfig.CROSSBOW_DURABILITY.get("stone");
        var draw = ArsenalConfig.CROSSBOW_DRAW_TICKS.get("stone");
        int oldDurability = durability.get();
        int oldDraw = draw.get();
        ItemStack existing = new ItemStack(ModItems.ITEMS.get("stone_crossbow").get());
        Player player = helper.makeMockPlayer(GameType.SURVIVAL);
        try {
            durability.set(1000);
            draw.set(15);
            helper.assertValueEqual(existing.getMaxDamage(), 1000, "existing crossbow live-config durability");
            helper.assertValueEqual(((MaterialCrossbowItem) existing.getItem()).chargeTicks(existing, player), 15,
                    "existing crossbow live-config charge ticks");
            ItemStack upgraded = Upgrades.apply(existing, UpgradeKind.DURABILITY, 1);
            helper.assertValueEqual(upgraded.getOrDefault(DataComponents.MAX_DAMAGE, 0), 600,
                    "raw crossbow durability must retain a single baseline-plus-upgrade scale");
            helper.assertValueEqual(upgraded.getMaxDamage(), 1200, "configured crossbow durability with level I");
            durability.set(500);
            helper.assertValueEqual(upgraded.getMaxDamage(), 600, "existing upgraded crossbow must follow config changes once");
        } finally {
            durability.set(oldDurability);
            draw.set(oldDraw);
        }
        helper.succeed();
    }
}
