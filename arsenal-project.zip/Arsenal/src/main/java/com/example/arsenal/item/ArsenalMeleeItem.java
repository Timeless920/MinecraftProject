package com.example.arsenal.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;
import net.neoforged.neoforge.common.ItemAbilities;
import net.neoforged.neoforge.common.ItemAbility;

/** Independent sword-based melee items; this never subclasses or changes vanilla MaceItem. */
public final class ArsenalMeleeItem extends SwordItem {
    private final MeleeKind kind;

    public ArsenalMeleeItem(Tier tier, MeleeKind kind, Item.Properties properties) {
        super(tier, properties.attributes(WeaponAttributes.create(tier, kind)));
        if (kind == MeleeKind.BATTLE_AXE) {
            throw new IllegalArgumentException("Battle axes must use ArsenalAxeItem");
        }
        this.kind = kind;
    }

    public MeleeKind kind() { return kind; }
    public Tier tier() { return getTier(); }

    @Override
    public boolean canPerformAction(ItemStack stack, ItemAbility ability) {
        // A spear or mace should not inherit the sword's area sweep.
        if (ability == ItemAbilities.SWORD_SWEEP && kind != MeleeKind.KATANA) return false;
        return super.canPerformAction(stack, ability);
    }
}
