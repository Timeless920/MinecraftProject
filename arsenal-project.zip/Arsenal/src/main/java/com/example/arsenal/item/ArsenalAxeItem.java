package com.example.arsenal.item;

import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Tier;

/** AxeItem supplies stripping, axe mining rules and NeoForge's canDisableShield hook. */
public final class ArsenalAxeItem extends AxeItem {
    public ArsenalAxeItem(Tier tier, Item.Properties properties) {
        super(tier, properties.attributes(WeaponAttributes.create(tier, MeleeKind.BATTLE_AXE)));
    }

    public MeleeKind kind() { return MeleeKind.BATTLE_AXE; }
    public Tier tier() { return getTier(); }
}
