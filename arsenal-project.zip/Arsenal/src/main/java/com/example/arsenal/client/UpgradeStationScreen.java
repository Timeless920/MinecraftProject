package com.example.arsenal.client;

import com.example.arsenal.ArsenalConfig;
import com.example.arsenal.station.UpgradeRecipe;
import com.example.arsenal.station.UpgradeStationMenu;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeHolder;

/** Client-only screen. Selection uses vanilla inventory button packets. */
public class UpgradeStationScreen extends AbstractContainerScreen<UpgradeStationMenu> {
    private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(
            "arsenal", "textures/gui/upgrade_station.png");
    private static final int LIST_X = 56;
    private static final int LIST_Y = 17;
    private static final int ROW_WIDTH = 80;
    private static final int ROW_HEIGHT = 18;
    private static final int VISIBLE_ROWS = 6;
    private int firstRow;

    public UpgradeStationScreen(UpgradeStationMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        imageWidth = 176;
        imageHeight = 222;
        inventoryLabelY = 128;
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        graphics.blit(TEXTURE, leftPos, topPos, 0, 0, imageWidth, imageHeight);
        List<RecipeHolder<UpgradeRecipe>> recipes = menu.availableRecipes();
        firstRow = Mth.clamp(firstRow, 0, Math.max(0, recipes.size() - VISIBLE_ROWS));
        for (int row = 0; row < VISIBLE_ROWS && firstRow + row < recipes.size(); row++) {
            int index = firstRow + row;
            int x = leftPos + LIST_X;
            int y = topPos + LIST_Y + row * ROW_HEIGHT;
            int color = menu.selectedIndex() == index ? 0xFF69876A : 0xFF444444;
            if (isHovering(LIST_X, LIST_Y + row * ROW_HEIGHT, ROW_WIDTH, ROW_HEIGHT, mouseX, mouseY)) {
                color = menu.selectedIndex() == index ? 0xFF8AA68A : 0xFF666666;
            }
            graphics.fill(x, y, x + ROW_WIDTH, y + ROW_HEIGHT - 1, color);
            UpgradeRecipe recipe = recipes.get(index).value();
            String label = font.plainSubstrByWidth(recipeLabel(recipe).getString(), ROW_WIDTH - 5);
            int textColor = minecraft != null && minecraft.player != null && menu.canAfford(recipe, minecraft.player)
                    ? 0xFFFFFF : 0xFFAAAA;
            graphics.drawString(font, label, x + 3, y + 5, textColor, false);
        }
        if (recipes.size() > VISIBLE_ROWS) {
            int trackX = leftPos + LIST_X + ROW_WIDTH + 2;
            int trackY = topPos + LIST_Y;
            int height = VISIBLE_ROWS * ROW_HEIGHT - 1;
            graphics.fill(trackX, trackY, trackX + 4, trackY + height, 0xFF333333);
            int thumbHeight = Math.max(10, height * VISIBLE_ROWS / recipes.size());
            int thumbY = trackY + (height - thumbHeight) * firstRow / (recipes.size() - VISIBLE_ROWS);
            graphics.fill(trackX, thumbY, trackX + 4, thumbY + thumbHeight, 0xFFAAAAAA);
        }
    }

    private Component recipeLabel(UpgradeRecipe recipe) {
        return Component.translatable("gui.arsenal.level", Component.translatable(recipe.kind().translationKey()),
                Component.translatable("enchantment.level." + recipe.level()));
    }

    @Override
    protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
        super.renderLabels(graphics, mouseX, mouseY);
        if (menu.availableRecipes().isEmpty()) {
            graphics.drawWordWrap(font, Component.translatable("gui.arsenal.no_upgrades"), LIST_X + 2, LIST_Y + 4,
                    ROW_WIDTH - 4, 0x404040);
        }
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        super.render(graphics, mouseX, mouseY, partialTick);
        renderTooltip(graphics, mouseX, mouseY);
        List<RecipeHolder<UpgradeRecipe>> recipes = menu.availableRecipes();
        for (int row = 0; row < VISIBLE_ROWS && firstRow + row < recipes.size(); row++) {
            if (isHovering(LIST_X, LIST_Y + row * ROW_HEIGHT, ROW_WIDTH, ROW_HEIGHT, mouseX, mouseY)) {
                UpgradeRecipe recipe = recipes.get(firstRow + row).value();
                List<Component> lines = new ArrayList<>();
                lines.add(recipeLabel(recipe));
                lines.add(costLabel(recipe.cost1()));
                recipe.cost2().ifPresent(cost -> lines.add(costLabel(cost)));
                if (ArsenalConfig.XP_COST.get() > 0) {
                    lines.add(Component.translatable("gui.arsenal.xp_cost", ArsenalConfig.XP_COST.get()));
                }
                graphics.renderComponentTooltip(font, lines, mouseX, mouseY);
                break;
            }
        }
    }

    private Component costLabel(UpgradeRecipe.Cost cost) {
        ItemStack[] alternatives = cost.ingredient().getItems();
        Component itemName = alternatives.length == 0 ? Component.literal("?") : alternatives[0].getHoverName();
        return Component.translatable("gui.arsenal.cost", Component.literal(cost.count() + " × ").append(itemName));
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0 && minecraft != null && minecraft.gameMode != null && minecraft.player != null) {
            List<RecipeHolder<UpgradeRecipe>> recipes = menu.availableRecipes();
            for (int row = 0; row < VISIBLE_ROWS && firstRow + row < recipes.size(); row++) {
                if (isHovering(LIST_X, LIST_Y + row * ROW_HEIGHT, ROW_WIDTH, ROW_HEIGHT, mouseX, mouseY)) {
                    int index = firstRow + row;
                    if (menu.clickMenuButton(minecraft.player, index)) {
                        minecraft.gameMode.handleInventoryButtonClick(menu.containerId, index);
                        return true;
                    }
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (isHovering(LIST_X, LIST_Y, ROW_WIDTH + 6, VISIBLE_ROWS * ROW_HEIGHT, mouseX, mouseY)) {
            int maximum = Math.max(0, menu.availableRecipes().size() - VISIBLE_ROWS);
            firstRow = Mth.clamp(firstRow - (int) Math.signum(verticalAmount), 0, maximum);
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }
}
