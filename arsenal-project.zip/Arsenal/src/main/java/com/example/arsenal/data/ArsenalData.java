package com.example.arsenal.data;

import com.google.gson.JsonParser;
import java.nio.file.Path;
import java.util.concurrent.CompletableFuture;
import net.minecraft.data.CachedOutput;
import net.minecraft.data.DataProvider;
import net.minecraft.data.PackOutput;
import net.neoforged.neoforge.data.event.GatherDataEvent;

/** Models and server data share a deterministic catalog; no client classes are loaded. */
public final class ArsenalData implements DataProvider {
    private final Path output;

    private ArsenalData(PackOutput output) {
        this.output = output.getOutputFolder();
    }

    public static void gather(GatherDataEvent event) {
        event.getGenerator().addProvider(event.includeClient() || event.includeServer(),
                new ArsenalData(event.getGenerator().getPackOutput()));
    }

    @Override
    public CompletableFuture<?> run(CachedOutput cache) {
        return CompletableFuture.allOf(ResourceCatalog.files().entrySet().stream()
                .map(entry -> DataProvider.saveStable(cache, JsonParser.parseString(entry.getValue()),
                        output.resolve(entry.getKey())))
                .toArray(CompletableFuture[]::new));
    }

    @Override
    public String getName() {
        return "Arsenal models, languages, recipes, item tags and block loot";
    }
}
