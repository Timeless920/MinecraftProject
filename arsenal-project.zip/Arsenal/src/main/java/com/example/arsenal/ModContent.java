package com.example.arsenal;

import com.example.arsenal.station.*;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.*;
import net.minecraft.world.item.crafting.*;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.*;

public final class ModContent {
    private static final DeferredRegister.Blocks BLOCKS=DeferredRegister.createBlocks(Arsenal.MOD_ID);
    private static final DeferredRegister<MenuType<?>> MENUS=DeferredRegister.create(Registries.MENU,Arsenal.MOD_ID);
    private static final DeferredRegister<RecipeType<?>> RECIPE_TYPES=DeferredRegister.create(Registries.RECIPE_TYPE,Arsenal.MOD_ID);
    private static final DeferredRegister<RecipeSerializer<?>> SERIALIZERS=DeferredRegister.create(Registries.RECIPE_SERIALIZER,Arsenal.MOD_ID);
    private static final DeferredRegister<CreativeModeTab> TABS=DeferredRegister.create(Registries.CREATIVE_MODE_TAB,Arsenal.MOD_ID);
    public static final DeferredBlock<UpgradeStationBlock> UPGRADE_STATION=BLOCKS.register("upgrade_station",
        ()->new UpgradeStationBlock(BlockBehaviour.Properties.ofFullCopy(Blocks.SMITHING_TABLE).strength(3.5f).requiresCorrectToolForDrops()));
    public static final DeferredItem<BlockItem> STATION_ITEM=ModItems.REGISTER.registerSimpleBlockItem(UPGRADE_STATION);
    public static final DeferredHolder<MenuType<?>,MenuType<UpgradeStationMenu>> UPGRADE_MENU=MENUS.register("upgrade_station",
        ()->new MenuType<>(UpgradeStationMenu::new,FeatureFlags.DEFAULT_FLAGS));
    public static final DeferredHolder<RecipeType<?>,RecipeType<UpgradeRecipe>> UPGRADE_RECIPE_TYPE=RECIPE_TYPES.register("upgrade",()->new RecipeType<>() {
        @Override public String toString(){return "arsenal:upgrade";}
    });
    public static final DeferredHolder<RecipeSerializer<?>,RecipeSerializer<UpgradeRecipe>> UPGRADE_RECIPE_SERIALIZER=SERIALIZERS.register("upgrade",UpgradeRecipe.Serializer::new);
    public static final DeferredHolder<CreativeModeTab,CreativeModeTab> TAB=TABS.register("arsenal",()->CreativeModeTab.builder()
        .title(Component.translatable("itemGroup.arsenal"))
        .icon(()->new ItemStack(ModItems.ITEMS.get("iron_katana").get()))
        .displayItems((parameters,output)->{ModItems.ITEMS.values().forEach(item->output.accept(item.get()));output.accept(STATION_ITEM.get());}).build());
    public static void register(IEventBus bus) {BLOCKS.register(bus);MENUS.register(bus);RECIPE_TYPES.register(bus);SERIALIZERS.register(bus);TABS.register(bus);}
    private ModContent() {}
}
