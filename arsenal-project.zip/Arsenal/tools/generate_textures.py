#!/usr/bin/env python3
"""Generate Arsenal's original, deliberately simple pixel-art placeholders.

Run from any working directory: python tools/generate_textures.py.
Requires the Pillow version in tools/requirements.txt. No external artwork,
Minecraft textures, network requests, or random input are used.
"""

from pathlib import Path

from PIL import Image, ImageDraw


ROOT = Path(__file__).resolve().parents[1]
TEXTURES = ROOT / "src/main/resources/assets/arsenal/textures"
PALETTES = {
    "wooden": ((151, 106, 60), (204, 154, 90), (88, 57, 36)),
    "stone": ((130, 137, 146), (184, 191, 194), (65, 71, 82)),
    "iron": ((193, 205, 212), (240, 246, 243), (102, 118, 130)),
    "golden": ((235, 177, 39), (255, 234, 104), (145, 97, 24)),
    "diamond": ((38, 190, 181), (149, 249, 223), (12, 100, 117)),
    "netherite": ((80, 66, 81), (139, 115, 128), (43, 35, 48)),
}
SHAFT = (110, 72, 43, 255)
LEATHER = (79, 43, 33, 255)
STRING = (231, 221, 200, 255)
OUTLINE = (34, 28, 32, 255)


def save(image: Image.Image, category: str, name: str) -> None:
    directory = TEXTURES / category
    directory.mkdir(parents=True, exist_ok=True)
    image.save(directory / f"{name}.png", optimize=False)


def canvas() -> tuple[Image.Image, ImageDraw.ImageDraw]:
    image = Image.new("RGBA", (16, 16))
    return image, ImageDraw.Draw(image)


def blade(draw: ImageDraw.ImageDraw, material: str, points: list[tuple[int, int]]) -> None:
    base, light, dark = PALETTES[material]
    draw.polygon(points, fill=base, outline=dark)
    if len(points) > 2:
        draw.line(points[1:3], fill=light, width=1)


def melee(material: str, kind: str) -> Image.Image:
    image, draw = canvas()
    base, light, dark = PALETTES[material]
    if kind == "katana":
        draw.line([(2, 14), (7, 9)], fill=OUTLINE, width=3)
        draw.line([(2, 14), (7, 9)], fill=LEATHER)
        draw.line([(5, 8), (8, 11)], fill=(194, 142, 49), width=2)
        blade(draw, material, [(7, 8), (11, 3), (15, 0), (13, 5), (9, 10)])
        draw.line([(8, 8), (12, 3), (14, 1)], fill=light)
        draw.point((3, 12), fill=(169, 110, 69))
        draw.point((5, 10), fill=(169, 110, 69))
    elif kind == "battle_axe":
        draw.line([(2, 14), (12, 4)], fill=OUTLINE, width=3)
        draw.line([(2, 14), (12, 4)], fill=SHAFT)
        blade(draw, material, [(4, 3), (9, 2), (12, 5), (12, 9), (9, 12), (8, 8), (4, 7)])
        blade(draw, material, [(10, 1), (14, 1), (15, 5), (13, 7), (11, 5)])
        draw.line([(5, 4), (8, 3)], fill=light)
        draw.line([(10, 8), (9, 10)], fill=light)
        draw.rectangle((9, 4, 11, 6), fill=dark)
    elif kind == "spear":
        draw.line([(1, 15), (12, 4)], fill=OUTLINE, width=3)
        draw.line([(1, 15), (12, 4)], fill=SHAFT)
        blade(draw, material, [(9, 5), (12, 1), (15, 0), (14, 4), (10, 7)])
        draw.line([(11, 4), (14, 1)], fill=light)
        draw.line([(7, 6), (10, 9)], fill=LEATHER)
        draw.line([(6, 7), (9, 10)], fill=LEATHER)
    elif kind == "mace":
        draw.line([(2, 14), (10, 6)], fill=OUTLINE, width=4)
        draw.line([(2, 14), (10, 6)], fill=SHAFT, width=2)
        draw.line([(1, 12), (4, 15)], fill=dark)
        blade(draw, material, [(8, 1), (12, 0), (15, 3), (15, 7), (11, 10), (6, 5)])
        draw.line([(9, 2), (13, 6), (11, 8)], fill=light, width=2)
        draw.line([(7, 4), (12, 9)], fill=dark)
        draw.point((14, 3), fill=light)
    else:
        raise ValueError(kind)
    return image


def bow(material: str, pull: int = -1) -> Image.Image:
    image, draw = canvas()
    base, light, dark = PALETTES[material]
    # Bow limbs remain recognizable as a diagonal weapon in the inventory.
    draw.line([(2, 3), (7, 2), (11, 5), (13, 9), (12, 14)], fill=dark, width=3)
    draw.line([(2, 3), (7, 2), (11, 5), (13, 9), (12, 14)], fill=base)
    draw.line([(7, 2), (10, 4)], fill=light)
    draw.line([(12, 9), (12, 12)], fill=light)
    draw.line([(10, 5), (12, 7)], fill=LEATHER, width=3)
    if pull < 0:
        draw.line([(2, 3), (12, 14)], fill=STRING)
    else:
        nock = (6 - pull, 8 + pull)
        draw.line([(2, 3), nock, (12, 14)], fill=STRING)
        draw.line([nock, (13, 1)], fill=SHAFT)
        draw.polygon([(12, 1), (15, 0), (14, 3)], fill=(209, 217, 218))
        draw.line([(nock[0] - 1, nock[1]), (nock[0], nock[1] + 1)], fill=STRING, width=2)
    return image


def crossbow(material: str, variant: str = "", pull: int = -1) -> Image.Image:
    image, draw = canvas()
    base, light, dark = PALETTES[material]
    draw.line([(2, 14), (12, 4)], fill=OUTLINE, width=4)
    draw.line([(2, 14), (12, 4)], fill=SHAFT, width=2)
    draw.line([(4, 15), (6, 12)], fill=LEATHER, width=2)
    draw.line([(3, 3), (8, 3), (12, 7), (12, 12)], fill=dark, width=3)
    draw.line([(3, 3), (8, 3), (12, 7), (12, 12)], fill=base)
    draw.line([(4, 3), (7, 3)], fill=light)
    draw.line([(12, 8), (12, 10)], fill=light)
    nock = (7 - max(pull, 0), 8 + max(pull, 0)) if pull >= 0 or variant else (8, 7)
    draw.line([(3, 3), nock, (12, 12)], fill=STRING)
    draw.rectangle((7, 6, 9, 8), fill=dark)
    if variant == "arrow":
        draw.line([(5, 10), (13, 2)], fill=SHAFT)
        draw.polygon([(11, 2), (15, 0), (13, 4)], fill=(215, 227, 229))
        draw.line([(4, 9), (6, 11)], fill=STRING)
    elif variant == "firework":
        draw.line([(6, 10), (11, 5)], fill=(180, 156, 108))
        draw.polygon([(8, 5), (11, 2), (14, 5), (11, 8)], fill=(242, 235, 204), outline=(193, 64, 54))
        draw.polygon([(11, 2), (12, 0), (15, 3), (14, 5)], fill=(191, 48, 46))
        draw.line([(9, 4), (12, 7)], fill=(203, 60, 47))
    return image


def block(face: str) -> Image.Image:
    image, draw = canvas()
    draw.rectangle((0, 0, 15, 15), fill=(61, 64, 69))
    draw.rectangle((1, 1, 14, 14), fill=(103, 110, 118), outline=(153, 159, 166))
    if face == "top":
        draw.rectangle((3, 3, 12, 12), fill=(46, 51, 61), outline=(32, 35, 44))
        draw.rectangle((5, 5, 10, 10), fill=(46, 130, 137), outline=(111, 202, 194))
        draw.line([(7, 6), (7, 9)], fill=(225, 228, 180))
        draw.line([(6, 7), (9, 7)], fill=(225, 228, 180))
        for x, y in [(2, 2), (13, 2), (2, 13), (13, 13)]:
            draw.point((x, y), fill=(230, 205, 119))
    elif face == "side":
        draw.rectangle((2, 3, 13, 11), fill=(65, 69, 76))
        draw.rectangle((4, 5, 11, 7), fill=(30, 38, 44), outline=(146, 151, 155))
        draw.line([(4, 12), (11, 12)], fill=(205, 165, 71))
        draw.rectangle((0, 14, 15, 15), fill=(43, 41, 45))
    elif face == "bottom":
        for y in (3, 7, 11):
            draw.line([(2, y), (13, y)], fill=(71, 74, 80))
        for x in (3, 12):
            draw.line([(x, 2), (x, 13)], fill=(71, 74, 80))
    return image


def gui() -> Image.Image:
    """176x222 container area; UV space intentionally remains 256x256."""
    image = Image.new("RGBA", (256, 256))
    draw = ImageDraw.Draw(image)
    draw.rectangle((0, 0, 175, 221), fill=(34, 36, 42))
    draw.rectangle((1, 1, 174, 220), fill=(218, 220, 219))
    draw.rectangle((3, 3, 172, 218), fill=(170, 177, 181))
    draw.line([(4, 217), (171, 217), (171, 4)], fill=(90, 98, 107), width=2)
    draw.rectangle((55, 17, 165, 126), fill=(69, 77, 88), outline=(35, 40, 48))
    # The screen draws translated labels and dynamically selected recipe rows.
    for y in (19, 39, 59, 79, 99):
        draw.rectangle((57, y, 163, y + 17), fill=(95, 108, 119))

    def slot(x: int, y: int) -> None:
        draw.rectangle((x - 1, y - 1, x + 16, y + 16), fill=(77, 84, 92))
        draw.line([(x - 1, y + 16), (x + 16, y + 16), (x + 16, y - 1)], fill=(231, 233, 231))
        draw.rectangle((x, y, x + 15, y + 15), fill=(123, 131, 139))

    for position in [(8, 20), (8, 44), (30, 44), (145, 44)]:
        slot(*position)
    for row in range(3):
        for column in range(9):
            slot(8 + column * 18, 140 + row * 18)
    for column in range(9):
        slot(8 + column * 18, 198)
    return image


def main() -> None:
    count = 0
    for material in PALETTES:
        for kind in ("katana", "battle_axe", "spear", "mace"):
            save(melee(material, kind), "item", f"{material}_{kind}")
            count += 1
        if material == "wooden":
            continue
        save(bow(material), "item", f"{material}_bow")
        save(crossbow(material), "item", f"{material}_crossbow")
        count += 2
        for stage in range(3):
            save(bow(material, stage), "item", f"{material}_bow_pulling_{stage}")
            save(crossbow(material, pull=stage), "item", f"{material}_crossbow_pulling_{stage}")
            count += 2
        for variant in ("arrow", "firework"):
            save(crossbow(material, variant), "item", f"{material}_crossbow_{variant}")
            count += 1
    for face in ("top", "side", "bottom"):
        save(block(face), "block", f"upgrade_station_{face}")
    save(gui(), "gui", "upgrade_station")
    print(f"Generated {count} original 16x16 item textures, 3 block textures, and a 256x256 GUI in {TEXTURES}")


if __name__ == "__main__":
    main()
