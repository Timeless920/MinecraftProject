#!/usr/bin/env bash
# Source this file in the Codex cloud machine; ordinary local builds only need a JDK 21.
export JAVA_HOME=/workspace/.arsenal-jdk
export GRADLE_USER_HOME=/workspace/.gradle
export PATH="$JAVA_HOME/bin:$PATH"

# Development game JVMs also need the cloud proxy, not only the Gradle daemon.
if [[ -z "${ARSENAL_JVM_PROXY_CONFIGURED:-}" && -n "${HTTPS_PROXY:-}" ]]; then
    arsenal_proxy_options=$(python3 - <<'PY'
import os
from urllib.parse import urlsplit
proxy = urlsplit(os.environ['HTTPS_PROXY'])
if proxy.hostname:
    print(f'-Dhttps.proxyHost={proxy.hostname} -Dhttps.proxyPort={proxy.port or 80} '
          f'-Dhttp.proxyHost={proxy.hostname} -Dhttp.proxyPort={proxy.port or 80} '
          '-Dhttp.nonProxyHosts=localhost|127.*|[::1] '
          '-Djavax.net.ssl.trustStore=/etc/ssl/certs/java/cacerts')
PY
)
    export JAVA_TOOL_OPTIONS="${JAVA_TOOL_OPTIONS:+$JAVA_TOOL_OPTIONS }$arsenal_proxy_options"
    export ARSENAL_JVM_PROXY_CONFIGURED=1
    unset arsenal_proxy_options
fi
