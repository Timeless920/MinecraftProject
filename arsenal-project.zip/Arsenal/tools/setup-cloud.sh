#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
source tools/cloud-env.sh

if [[ ! -x "$JAVA_HOME/bin/javac" ]]; then
    arsenal_download_dir=$(mktemp -d /tmp/arsenal-jdk.XXXXXX)
    trap 'rm -rf "$arsenal_download_dir"' EXIT
    arsenal_archive=OpenJDK21U-jdk_x64_linux_hotspot_21.0.8_9.tar.gz
    curl --fail --location --show-error --retry 2 \
        "https://github.com/adoptium/temurin21-binaries/releases/download/jdk-21.0.8%2B9/$arsenal_archive" \
        --output "$arsenal_download_dir/$arsenal_archive"
    printf '%s  %s\n' f2dc5418092c43003db8f9005c4a286e1c0104fea96ccdd49e8ebd037cac9219 \
        "$arsenal_download_dir/$arsenal_archive" | sha256sum --check --status
    mkdir -p "$JAVA_HOME"
    tar -xzf "$arsenal_download_dir/$arsenal_archive" --strip-components=1 -C "$JAVA_HOME"
fi

# Forward the platform's proxy to Gradle without reading or saving any credentials.
# Keep all unrelated user Gradle settings. Use the system's trusted CA store.
python3 - <<'PY'
import os
from pathlib import Path
from urllib.parse import urlsplit
proxy = urlsplit(os.environ.get('HTTPS_PROXY', ''))
if proxy.hostname:
    path = Path(os.environ['GRADLE_USER_HOME']) / 'gradle.properties'
    path.parent.mkdir(parents=True, exist_ok=True)
    settings = {
        'systemProp.https.proxyHost': proxy.hostname,
        'systemProp.https.proxyPort': str(proxy.port or 80),
        'systemProp.http.proxyHost': proxy.hostname,
        'systemProp.http.proxyPort': str(proxy.port or 80),
        'systemProp.javax.net.ssl.trustStore': '/etc/ssl/certs/java/cacerts',
    }
    previous = path.read_text().splitlines() if path.exists() else []
    retained = [line for line in previous if line.split('=', 1)[0].strip() not in settings]
    path.write_text('\n'.join(retained + [f'{key}={value}' for key, value in settings.items()]) + '\n')
PY
if [[ ! -x /workspace/.arsenal-tools/bin/python ]]; then
    python3 -m venv /workspace/.arsenal-tools
fi
/workspace/.arsenal-tools/bin/python -m pip install --no-cache-dir --disable-pip-version-check -r tools/requirements.txt
./gradlew build --console=plain
