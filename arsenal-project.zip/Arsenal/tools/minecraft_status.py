#!/usr/bin/env python3
"""Make a real Minecraft 1.21.1 status request to the local development server."""
import json
import socket
import struct


def varint(value):
    result = bytearray()
    while True:
        byte = value & 127
        value >>= 7
        result.append(byte | (128 if value else 0))
        if not value:
            return bytes(result)


def read_varint(connection):
    value = 0
    for index in range(5):
        data = connection.recv(1)
        if not data:
            raise EOFError("Server closed the status connection")
        byte = data[0]
        value |= (byte & 127) << (7 * index)
        if not byte & 128:
            return value
    raise ValueError("Invalid Minecraft VarInt")


def main():
    host, port, protocol = "127.0.0.1", 25565, 767
    encoded_host = host.encode("utf-8")
    handshake = (varint(0) + varint(protocol) + varint(len(encoded_host))
                 + encoded_host + struct.pack(">H", port) + varint(1))
    with socket.create_connection((host, port), timeout=5) as connection:
        connection.sendall(varint(len(handshake)) + handshake + b"\x01\x00")
        read_varint(connection)
        if read_varint(connection) != 0:
            raise ValueError("Unexpected Minecraft status response packet")
        size = read_varint(connection)
        if not 0 < size <= 1_048_576:
            raise ValueError("Invalid Minecraft status response size")
        payload = bytearray()
        while len(payload) < size:
            chunk = connection.recv(size - len(payload))
            if not chunk:
                raise EOFError("Truncated Minecraft status response")
            payload.extend(chunk)
    status = json.loads(payload)
    if status["version"]["protocol"] != protocol:
        raise ValueError("Unexpected Minecraft protocol version")
    print(json.dumps({"status": "ok", "version": status["version"],
                      "players_online": status["players"]["online"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
